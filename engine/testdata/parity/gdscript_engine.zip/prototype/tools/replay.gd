extends SceneTree
## Replays one seeded battle and writes every step as JSON (for the Studio replay view).
##
## godot --headless --path . --script res://tools/replay.gd -- \
##     --battle=1-4 --bot=skilled --seed=0 --out=<file.json> [--max-rounds=30] [--data-dir=...]
##
## Output: {battle, bot, seed, result, rounds, frames: [{round, actor, lines, units}]}
## frames[0] is the starting position; each later frame is the state after one batch of events.


func _init() -> void:
	var args := {"battle": "1-4", "bot": "skilled", "seed": "0", "out": "", "max-rounds": "30"}
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--") and a.contains("="):
			var kv := a.trim_prefix("--").split("=", true, 1)
			args[kv[0]] = kv[1]
	if args["out"] == "":
		push_error("missing --out=<file.json>")
		quit(2)
		return
	var frames: Array = []
	var start := Battles.build(args["battle"], SkillTree.default_picks())
	frames.append({"round": 1, "actor": "", "lines": [], "units": _snapshot(start), "cave": _cave(start)})
	var hook := func(s: BattleState, events: Array, actor: String) -> void:
		if events.is_empty():
			return
		var lines := EventText.describe(s, events)
		if lines.is_empty():
			return
		frames.append({"round": s.round_number, "actor": actor, "lines": lines, "units": _snapshot(s), "cave": _cave(s)})
	var rec := BattleRunner.run(args["battle"], SkillTree.default_picks(), PlayerBot.profile(args["bot"]),
		int(args["seed"]), int(args["max-rounds"]), hook)
	var out := {"battle": args["battle"], "bot": args["bot"], "seed": int(args["seed"]),
		"result": rec["result"], "rounds": rec["rounds"], "frames": frames}
	var f := FileAccess.open(args["out"], FileAccess.WRITE)
	f.store_string(JSON.stringify(out))
	f.close()
	print("replay written: %d frames" % frames.size())
	quit(0)


func _snapshot(s: BattleState) -> Dictionary:
	var out := {}
	for id in s.order:
		var u: UnitState = s.units[id]
		out[id] = {"def": u.def_id, "name": u.display_name,
			"team": "player" if u.team == Defs.Team.PLAYER else ("enemy" if u.team == Defs.Team.ENEMY else "neutral"),
			"pos": [u.pos.x, u.pos.y], "size": u.size, "hp": maxi(u.hp, 0), "max_hp": u.max_hp,
			"facing": _facing(u.facing), "alive": u.alive, "hidden": u.hidden, "statuses": u.statuses.keys(),
			"grappled_by": u.grappled_by_id, "escape": u.escape, "stagger": u.stagger, "stagger_max": u.stagger_max}
	return out


func _cave(s: BattleState) -> Dictionary:
	if s.cave.is_empty():
		return {}
	var entrances := []
	for id in s.cave["entrances"]:
		var e: Dictionary = s.cave["entrances"][id]
		entrances.append({"id": id, "anchor": [e["anchor"].x, e["anchor"].y], "sealed": e["sealed"]})
	var boulders := []
	for id in s.cave["boulders"]:
		var b: Dictionary = s.cave["boulders"][id]
		boulders.append({"id": id, "pos": [b["pos"].x, b["pos"].y], "placed": b["placed"], "progress": b["progress"]})
	return {"entrances": entrances, "boulders": boulders}


func _facing(v: Vector2i) -> String:
	if v == Defs.NORTH:
		return "N"
	if v == Defs.EAST:
		return "E"
	if v == Defs.WEST:
		return "W"
	return "S"
