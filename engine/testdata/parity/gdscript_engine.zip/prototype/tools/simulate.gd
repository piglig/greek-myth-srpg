extends SceneTree
## Batch battle simulation for the balance tooling. Writes one JSON line per battle.
##
## godot --headless --path . --script res://tools/simulate.gd -- \
##     --battle=1-4 --bot=skilled --runs=50 --seed=0 --out=<file.jsonl> [--picks=<json>] [--max-rounds=30]
##     [--trace=1]   print a readable event log (replay one seed to see what a bot actually did)
##
## Run i uses seed (seed + i), so splitting a seed range across processes is reproducible.
## --picks takes {"hero": [...], "atalanta": [...]} as JSON; default = the table's default picks.


func _init() -> void:
	var args := {"battle": "1-4", "bot": "skilled", "runs": "10", "seed": "0", "out": "",
		"picks": "", "max-rounds": "30", "trace": "0"}
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--") and a.contains("="):
			var kv := a.trim_prefix("--").split("=", true, 1)
			args[kv[0]] = kv[1]
	if args["out"] == "":
		push_error("missing --out=<file.jsonl>")
		quit(2)
		return
	var picks: Dictionary = SkillTree.default_picks()
	if args["picks"] != "":
		picks = JSON.parse_string(args["picks"])
	var prof := PlayerBot.profile(args["bot"])
	var f := FileAccess.open(args["out"], FileAccess.WRITE)
	var runs := int(args["runs"])
	var seed0 := int(args["seed"])
	for i in runs:
		var hook := Callable()
		if args["trace"] == "1":
			hook = func(s: BattleState, events: Array, _actor: String) -> void:
				for line in EventText.describe(s, events):
					print("    [R%d] %s" % [s.round_number, line])
		var rec := BattleRunner.run(args["battle"], picks, prof, seed0 + i, int(args["max-rounds"]), hook)
		f.store_line(JSON.stringify(rec))
		f.flush()
		print("run %d/%d seed %d: %s in %d rounds (%d ms)" % [i + 1, runs, seed0 + i, rec["result"], rec["rounds"], rec["ms"]])
	f.close()
	quit(0)
