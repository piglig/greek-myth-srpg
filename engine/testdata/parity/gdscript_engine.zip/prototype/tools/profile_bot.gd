extends SceneTree
## Times the pieces of one skilled-bot turn on 1-4 (development aid for simulation speed).
## godot --headless --path . --script res://tools/profile_bot.gd


func _init() -> void:
	var s := Battles.build("1-4")
	Rules.start_battle(s)
	var prof := PlayerBot.profile("skilled")
	Evaluator.begin_turn()
	for u in s.living(Defs.Team.PLAYER):
		var t0 := Time.get_ticks_usec()
		var ps := PlayerBot.plans(s, u, prof)
		var t_gen := Time.get_ticks_usec() - t0
		var t_copy := 0
		var t_apply := 0
		var t_score := 0
		for p in ps:
			var a := Time.get_ticks_usec()
			var c := s.copy()
			var b := Time.get_ticks_usec()
			PlayerBot.apply_plan(c, u.id, p, prof)
			var d := Time.get_ticks_usec()
			Evaluator.score(c, prof["weights"])
			var e := Time.get_ticks_usec()
			t_copy += b - a
			t_apply += d - b
			t_score += e - d
		print("%-9s plans %3d | gen %6.1f ms | copy %6.1f | apply %6.1f | score %6.1f" % [u.id, ps.size(),
			t_gen / 1000.0, t_copy / 1000.0, t_apply / 1000.0, t_score / 1000.0])
	var t1 := Time.get_ticks_usec()
	for i in 100:
		Movement.destinations(s, s.unit("hero"))
	print("destinations x100: %.1f ms" % ((Time.get_ticks_usec() - t1) / 1000.0))
	var t2 := Time.get_ticks_usec()
	for i in 100:
		s.copy()
	print("state copy x100: %.1f ms" % ((Time.get_ticks_usec() - t2) / 1000.0))
	var t3 := Time.get_ticks_usec()
	for e in s.living(Defs.Team.ENEMY):
		EnemyAI.threat_cells(s, e)
	print("threat cells (all enemies): %.1f ms" % ((Time.get_ticks_usec() - t3) / 1000.0))
	quit(0)
