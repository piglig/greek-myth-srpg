extends SceneTree
## Where a simulated battle spends its time: player search vs enemy AI vs phase bookkeeping.
## godot --headless --path . --script res://tools/profile_battle.gd -- --battle=1-4 --bot=skilled --seed=0


func _init() -> void:
	var args := {"battle": "1-4", "bot": "skilled", "seed": "0"}
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--") and a.contains("="):
			var kv := a.trim_prefix("--").split("=", true, 1)
			args[kv[0]] = kv[1]
	var s := Battles.build(args["battle"], SkillTree.default_picks())
	Rules.start_battle(s)
	var prof := PlayerBot.profile(args["bot"])
	var rng := RandomNumberGenerator.new()
	rng.seed = int(args["seed"])
	var t_player := 0
	var t_enemy := 0
	var t_other := 0
	var turns := 0
	while s.round_number <= 30:
		var a := Time.get_ticks_usec()
		PlayerBot.play_turn(s, rng, prof)
		var b := Time.get_ticks_usec()
		t_player += b - a
		turns += 1
		if _over(s):
			break
		Rules.end_phase(s)
		var c := Time.get_ticks_usec()
		t_other += c - b
		for e in s.living(Defs.Team.ENEMY):
			var guard := 0
			while e.alive and not e.has_acted and guard < 4:
				guard += 1
				var p := EnemyAI.plan(s, e)
				if p.has("move_to"):
					Rules.perform(s, {"type": "move", "unit": e.id, "to": p["move_to"]})
				if not Rules.perform(s, p["action"])["ok"]:
					Rules.perform(s, {"type": "wait", "unit": e.id})
				if not Rules.finish_activation(s, e):
					break
		var d := Time.get_ticks_usec()
		t_enemy += d - c
		if _over(s):
			break
		Rules.end_phase(s)
		t_other += Time.get_ticks_usec() - d
	print("%s %s seed %s: %d player turns" % [args["battle"], args["bot"], args["seed"], turns])
	print("player search %7.1f ms (%.1f per turn)" % [t_player / 1000.0, t_player / 1000.0 / turns])
	print("enemy AI      %7.1f ms (%.1f per turn)" % [t_enemy / 1000.0, t_enemy / 1000.0 / turns])
	print("phase changes %7.1f ms" % (t_other / 1000.0))
	for k in PlayerBot.stats:
		print("  %-22s %s" % [k, PlayerBot.stats[k]])
	quit(0)


func _over(s: BattleState) -> bool:
	return not s.unit("hero").alive or s.living(Defs.Team.ENEMY).is_empty() or s.living(Defs.Team.PLAYER).is_empty()
