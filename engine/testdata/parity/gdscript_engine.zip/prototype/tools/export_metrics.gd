extends SceneTree
## Exports a static damage matrix computed with the real rules (Damage.compute), for the
## Python balance specs. No battle is simulated: one hit, flat ground, no marks or flanks.
##
## Usage: godot --headless --path . --script res://tools/export_metrics.gd -- --out=<file.json>
##
## Scenarios (target facing relative to the attacker standing west of it):
##   front, side, back, broken_side (side + target in the "staggered" broken state)

const SCENARIOS := {
	"front": {"facing": Vector2i(-1, 0), "broken": false},
	"side": {"facing": Vector2i(0, -1), "broken": false},
	"back": {"facing": Vector2i(1, 0), "broken": false},
	"broken_side": {"facing": Vector2i(0, -1), "broken": true},
}


func _init() -> void:
	var out_path := ""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			out_path = arg.trim_prefix("--out=")
	if out_path == "":
		push_error("missing --out=<file>")
		quit(2)
		return

	var units := UnitCatalog.units()
	var rows: Array = []
	for atk_def in units:
		for skill_id in _usable_skills(atk_def):
			var sk := SkillCatalog.get_skill(skill_id)
			for tgt_def in units:
				for scen in SCENARIOS:
					rows.append(_hit(atk_def, skill_id, sk, tgt_def, scen))

	var unit_info := {}
	for def_id in units:
		var u := UnitCatalog.make(def_id, def_id, Defs.Team.ENEMY, Vector2i.ZERO)
		unit_info[def_id] = {"hp": u.hp, "max_hp": u.max_hp, "size": u.size}

	var f := FileAccess.open(out_path, FileAccess.WRITE)
	f.store_string(JSON.stringify({"units": unit_info, "hits": rows}, "  "))
	f.close()
	print("exported %d hits to %s" % [rows.size(), out_path])
	quit(0)


## Base kit plus every skill the unit can learn from its skill tree.
func _usable_skills(def_id: String) -> Array:
	var out: Array = (UnitCatalog.unit_def(def_id)["skills"] as Array).duplicate()
	for branch in SkillTree.trees().get(def_id, []):
		for n in branch["nodes"]:
			if n.has("skill") and not out.has(n["skill"]):
				out.append(n["skill"])
	# area-control skills (roar) deal no damage: nothing to tabulate
	return out.filter(func(id): return SkillCatalog.get_skill(id).has("mult"))


func _hit(atk_def: String, skill_id: String, sk: Dictionary, tgt_def: String, scen: String) -> Dictionary:
	# Target anchored at (4, 1); attacker directly west of it, adjacent whatever its size.
	var s := BattleState.new(BattleGrid.new(8, 5))
	var a := UnitCatalog.make(atk_def, "a", Defs.Team.PLAYER, Vector2i.ZERO, Defs.EAST)
	a.pos = Vector2i(4 - a.size, 1)
	s.add_unit(a)
	var t := s.add_unit(UnitCatalog.make(tgt_def, "t", Defs.Team.ENEMY, Vector2i(4, 1), SCENARIOS[scen]["facing"]))
	assert(Rules.distance(a, t) == 1, "fixture units must be adjacent")
	if SCENARIOS[scen]["broken"]:
		t.statuses["staggered"] = 2
	var hit := Damage.compute(s, a, t, sk["mult"], sk["type"], sk.get("ranged", false))
	return {
		"attacker": atk_def, "skill": skill_id, "target": tgt_def, "scenario": scen,
		"damage": hit["amount"], "immune": hit["immune"], "relation": hit["relation"],
	}
