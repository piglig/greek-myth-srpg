class_name Effects
extends RefCounted
## Low-level state changes shared by every action: damage, statuses, stagger, knockback,
## grapple bookkeeping. Each appends event dictionaries to `events`.


static func deal(state: BattleState, target: UnitState, amount: int, dmg_type: int, source: String,
		events: Array, can_dodge: bool = true) -> int:
	if not target.alive:
		return 0
	if can_dodge and target.has_status("dodge") and amount > 0:
		target.statuses.erase("dodge")
		events.append({"type": "dodge", "target": target.id, "source": source})
		return 0
	var dealt := amount
	if target.shield > 0 and dealt > 0:
		var absorbed := mini(target.shield, dealt)
		target.shield -= absorbed
		dealt -= absorbed
		events.append({"type": "shield", "target": target.id, "absorbed": absorbed})
	target.hp -= dealt
	events.append({"type": "damage", "target": target.id, "amount": dealt,
		"dmg_type": dmg_type, "source": source, "hp": target.hp})
	if target.hp <= 0:
		knock_out(state, target, events)
	return dealt


static func knock_out(state: BattleState, u: UnitState, events: Array) -> void:
	if not u.alive:
		return
	u.hp = mini(u.hp, 0)
	u.alive = false
	end_grapples_of(state, u, events, "ko")
	if state.marked_id == u.id:
		state.marked_id = ""
	events.append({"type": "ko", "target": u.id})


## Applies a status. Bosses ignore control statuses unless `bypass_armor` is set.
static func add_status(state: BattleState, u: UnitState, status: String, rounds: int,
		events: Array, bypass_armor: bool = false) -> bool:
	var is_control: bool = Defs.CONTROL_STATUSES.has(status)
	if is_control and not bypass_armor:
		if u.is_boss() and not u.has_status("staggered"):
			events.append({"type": "resist", "target": u.id, "status": status, "why": "super_armor"})
			return false
		if u.has_status("control_immune"):
			events.append({"type": "resist", "target": u.id, "status": status, "why": "control_immune"})
			return false
	u.statuses[status] = maxi(int(u.statuses.get(status, 0)), rounds)
	events.append({"type": "status", "target": u.id, "status": status, "rounds": rounds})
	if (is_control or status == "petrified") and u.grappling_id != "":
		end_grapple(state, u, events, "controlled")
	return true


static func add_stagger(u: UnitState, amount: int, events: Array) -> void:
	if not u.is_boss() or not u.alive or amount <= 0 or u.has_status("staggered"):
		return
	u.stagger += amount
	events.append({"type": "stagger", "target": u.id, "amount": amount, "total": u.stagger})
	if u.stagger >= u.stagger_max:
		u.stagger = 0
		# Broken: stunned through the next enemy phase, vulnerable until the end of the next round.
		u.statuses["stunned"] = 1
		u.statuses["staggered"] = 2
		events.append({"type": "broken", "target": u.id})


## Pushes `target` `steps` tiles along `dir` (docs/07 §5.1).
static func knockback(state: BattleState, target: UnitState, dir: Vector2i, steps: int,
		source: String, events: Array) -> void:
	if not target.alive or steps <= 0:
		return
	var start := target.pos
	var total_drop := 0
	for i in steps:
		var nxt := target.pos + dir
		var cur_h := state.unit_height(target)
		if not state.footprint_in_bounds(nxt, target.size) or _drowns(state, target, nxt):
			_edge(state, target, events)
			break
		var hit := state.blockers(nxt, target.size, target)
		if not hit.is_empty():
			events.append({"type": "collision", "target": target.id, "with": hit[0].id})
			deal(state, target, Defs.COLLISION_DAMAGE, Defs.DamageType.TRUE, "collision", events, false)
			deal(state, hit[0], Defs.COLLISION_DAMAGE, Defs.DamageType.TRUE, "collision", events, false)
			break
		var nxt_h := state.standing_height(nxt, target.size)
		if nxt_h > cur_h or state.boulder_in(nxt, target.size):
			events.append({"type": "collision", "target": target.id, "with": "wall"})
			deal(state, target, Defs.COLLISION_DAMAGE, Defs.DamageType.TRUE, "collision", events, false)
			break
		total_drop += cur_h - nxt_h
		target.pos = nxt
	if not target.alive:
		return
	if target.pos != start:
		events.append({"type": "knockback", "target": target.id, "from": start, "to": target.pos})
		end_grapples_of(state, target, events, "displaced")
	add_stagger(target, Defs.STAGGER_KNOCKBACK, events)
	if total_drop > 0:
		events.append({"type": "fall", "target": target.id, "levels": total_drop})
		deal(state, target, total_drop * Defs.FALL_DAMAGE_PER_LEVEL, Defs.DamageType.TRUE, "fall",
			events, false)
		add_stagger(target, total_drop * Defs.STAGGER_FALL_PER_LEVEL, events)


static func _drowns(state: BattleState, u: UnitState, anchor: Vector2i) -> bool:
	if u.has_trait("flying"):
		return false
	for c in u.footprint(anchor):
		if state.grid.terrain_at(c) == Defs.Terrain.DEEP:
			return true
	return false


static func _edge(state: BattleState, u: UnitState, events: Array) -> void:
	events.append({"type": "edge", "target": u.id})
	if u.team == Defs.Team.ENEMY and not u.is_boss():
		knock_out(state, u, events)
	else:
		deal(state, u, Defs.EDGE_DAMAGE, Defs.DamageType.TRUE, "edge", events, false)


# --- Grapple bookkeeping -------------------------------------------------------

static func escape_value(grappler: UnitState, target: UnitState) -> int:
	var v := Defs.ESCAPE_BASE + floori((grappler.strength - target.strength) / 4.0) - (target.size - 1)
	var cap := Defs.ESCAPE_MAX_BOSS if target.is_boss() else Defs.ESCAPE_MAX
	return clampi(v, Defs.ESCAPE_MIN, cap)


static func escape_cap(target: UnitState) -> int:
	return Defs.ESCAPE_MAX_BOSS if target.is_boss() else Defs.ESCAPE_MAX


static func end_grapple(state: BattleState, grappler: UnitState, events: Array, why: String) -> void:
	if grappler == null or grappler.grappling_id == "":
		return
	var target := state.unit(grappler.grappling_id)
	grappler.grappling_id = ""
	if target != null:
		target.grappled_by_id = ""
		target.escape = 0
	if why == "escaped":
		grappler.statuses.erase("guard")
	events.append({"type": "grapple_end", "grappler": grappler.id,
		"target": target.id if target != null else "", "why": why})


## Ends any grapple `u` takes part in, as grappler or target.
static func end_grapples_of(state: BattleState, u: UnitState, events: Array, why: String) -> void:
	if u.grappling_id != "":
		end_grapple(state, u, events, why)
	if u.grappled_by_id != "":
		end_grapple(state, state.unit(u.grappled_by_id), events, why)
