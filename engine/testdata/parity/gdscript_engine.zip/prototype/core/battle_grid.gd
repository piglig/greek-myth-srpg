class_name BattleGrid
extends RefCounted
## Tile heights and terrain. The grid is the gameplay truth; any 3DGS visual sits on top of it.

var width: int
var depth: int
var _heights := PackedInt32Array()
var _terrain := PackedInt32Array()

const TERRAIN_CHARS := {
	".": Defs.Terrain.PLAIN,
	"f": Defs.Terrain.FOREST,
	"w": Defs.Terrain.SHALLOW,
	"D": Defs.Terrain.DEEP,
	"s": Defs.Terrain.SWAMP,
	"b": Defs.Terrain.BURNING,
	"x": Defs.Terrain.STYX,
}


func _init(w: int = 1, d: int = 1, default_height: int = 0) -> void:
	width = w
	depth = d
	_heights.resize(w * d)
	_heights.fill(default_height)
	_terrain.resize(w * d)
	_terrain.fill(Defs.Terrain.PLAIN)


## Builds a grid from rows of height digits, e.g. ["0012", "0012"].
## Optional terrain rows use TERRAIN_CHARS.
static func from_rows(height_rows: Array, terrain_rows: Array = []) -> BattleGrid:
	var d := height_rows.size()
	var w := (height_rows[0] as String).length()
	var grid := BattleGrid.new(w, d)
	for y in d:
		var row: String = height_rows[y]
		assert(row.length() == w, "uneven height row %d" % y)
		for x in w:
			grid.set_height(Vector2i(x, y), int(row[x]))
	for y in terrain_rows.size():
		var row: String = terrain_rows[y]
		for x in row.length():
			grid.set_terrain(Vector2i(x, y), TERRAIN_CHARS.get(row[x], Defs.Terrain.PLAIN))
	return grid


func in_bounds(c: Vector2i) -> bool:
	return c.x >= 0 and c.y >= 0 and c.x < width and c.y < depth


func height_at(c: Vector2i) -> int:
	return _heights[_index(c)]


func set_height(c: Vector2i, h: int) -> void:
	_heights[_index(c)] = clampi(h, 0, Defs.MAX_HEIGHT)


func terrain_at(c: Vector2i) -> int:
	return _terrain[_index(c)]


func set_terrain(c: Vector2i, t: int) -> void:
	_terrain[_index(c)] = t


func copy() -> BattleGrid:
	var g := BattleGrid.new(width, depth)
	g._heights = _heights.duplicate()
	g._terrain = _terrain.duplicate()
	return g


func _index(c: Vector2i) -> int:
	assert(in_bounds(c), "cell out of bounds: %s" % c)
	return c.y * width + c.x
