class_name UnitState
extends RefCounted
## Runtime state of one unit. Pure data; rules live in Rules and helpers.

var id := ""
var def_id := ""
var display_name := ""
var team: int = Defs.Team.PLAYER
var pos := Vector2i.ZERO  ## top-left anchor of the footprint
var size := 1
var facing: Vector2i = Defs.SOUTH

var max_hp := 1
var hp := 1
var strength := 0
var divinity := 0
var defense := 0
var will := 0
var move := 4
var jump := 1

var skills: Array[String] = []
## Trait keys: physical_immune, block, forest_stride, flying, cannot_attack_adjacent,
## hunter_mark, grapple (value = choke damage), guest.
var traits := {}
## Status name -> remaining rounds. "staggered" and "stunned" are set by the stagger system.
var statuses := {}
var shield := 0
var cooldowns := {}

var stagger := 0
var stagger_max := 0  ## > 0 marks a boss with a stagger bar

var actions_per_turn := 1
var actions_left := 0
var has_moved := false
var has_acted := false
var assist_used := false
var mark_used := false
var intercept_used := false
var post_move := 0  ## move points granted after acting (skirmish)

var grappling_id := ""
var grappled_by_id := ""
var escape := 0

var alive := true
var hidden := false  ## off the board (the lion inside its cave): cannot be targeted, blocks nothing


func is_boss() -> bool:
	return stagger_max > 0


func has_trait(key: String) -> bool:
	return traits.has(key)


func has_status(key: String) -> bool:
	return statuses.has(key)


func footprint(anchor: Vector2i = Defs.NO_POS) -> Array[Vector2i]:
	if anchor == Defs.NO_POS:
		anchor = pos
	var cells: Array[Vector2i] = []
	for dy in size:
		for dx in size:
			cells.append(anchor + Vector2i(dx, dy))
	return cells


func occupies(c: Vector2i) -> bool:
	return c.x >= pos.x and c.y >= pos.y and c.x < pos.x + size and c.y < pos.y + size


func center(anchor: Vector2i = Defs.NO_POS) -> Vector2:
	if anchor == Defs.NO_POS:
		anchor = pos
	return Vector2(anchor) + Vector2(size, size) * 0.5


func cooldown(skill_id: String) -> int:
	return int(cooldowns.get(skill_id, 0))


## Explicit field copy (reflection-based copying was the simulation hot spot).
## Keep in sync with the field list above; test_turns checks copies are independent.
func copy() -> UnitState:
	var u := UnitState.new()
	u.id = id
	u.def_id = def_id
	u.display_name = display_name
	u.team = team
	u.pos = pos
	u.size = size
	u.facing = facing
	u.max_hp = max_hp
	u.hp = hp
	u.strength = strength
	u.divinity = divinity
	u.defense = defense
	u.will = will
	u.move = move
	u.jump = jump
	u.skills = skills.duplicate()
	u.traits = traits  # definition data, never mutated during a battle
	u.statuses = statuses.duplicate()
	u.shield = shield
	u.cooldowns = cooldowns.duplicate()
	u.stagger = stagger
	u.stagger_max = stagger_max
	u.actions_per_turn = actions_per_turn
	u.actions_left = actions_left
	u.has_moved = has_moved
	u.has_acted = has_acted
	u.assist_used = assist_used
	u.mark_used = mark_used
	u.intercept_used = intercept_used
	u.post_move = post_move
	u.grappling_id = grappling_id
	u.grappled_by_id = grappled_by_id
	u.escape = escape
	u.alive = alive
	u.hidden = hidden
	return u
