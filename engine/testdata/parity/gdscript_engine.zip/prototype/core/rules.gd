class_name Rules
extends RefCounted
## Action validation, execution, preview and phase flow (docs/07 §2, §7.1).
##
## Actions are dictionaries:
##   {"type": "move", "unit": id, "to": Vector2i}
##   {"type": "undo_move", "unit": id}
##   {"type": "skill", "unit": id, "skill": skill_id, "target": Vector2i, "to": Vector2i (leap skills)}
##   {"type": "slam", "unit": id, "target": Vector2i}  (a cell next to the held unit: throw direction)
##   {"type": "grapple", "unit": id, "target": Vector2i}
##   {"type": "reinforce" | "struggle" | "release" | "wait", "unit": id}
##   {"type": "face", "unit": id, "facing": Vector2i}
##   {"type": "mark", "unit": id, "target": Vector2i}
## perform() returns {"ok": bool, "error": String, "action": Dictionary, "events": Array}.
## preview() runs the same code on a copy, so what the UI shows is exactly what will happen.

const FREE_ACTIONS := ["face", "mark", "release", "undo_move"]


static func preview(state: BattleState, action: Dictionary) -> Dictionary:
	return perform(state.copy(), action)


static func perform(state: BattleState, action: Dictionary) -> Dictionary:
	var err := validate(state, action)
	var outcome := {"ok": err == "", "error": err, "action": action, "events": []}
	if err != "":
		return outcome
	var events: Array = outcome["events"]
	var u := state.unit(action["unit"])
	match action["type"]:
		"move":
			_do_move(state, u, action["to"], events)
		"undo_move":
			_do_undo_move(state, u, events)
		"skill":
			_do_skill(state, u, action, events)
		"slam":
			_do_slam(state, u, action["target"], events)
		"grapple":
			_do_grapple(state, u, state.unit_at(action["target"]), events)
		"reinforce":
			var t := state.unit(u.grappling_id)
			t.escape = mini(t.escape + 1, Effects.escape_cap(t))
			u.has_acted = true
			events.append({"type": "reinforce", "unit": u.id, "escape": t.escape})
		"struggle":
			# A boss tears free twice as fast: holding one costs it an action, not its whole turn.
			u.escape -= Defs.BOSS_STRUGGLE if u.is_boss() else 1
			u.has_acted = true
			events.append({"type": "struggle", "unit": u.id, "escape": u.escape})
			if u.escape <= 0:
				Effects.end_grapple(state, state.unit(u.grappled_by_id), events, "escaped")
		"release":
			Effects.end_grapple(state, u, events, "released")
		"wait":
			u.statuses["guard"] = 1
			u.has_acted = true
			events.append({"type": "status", "target": u.id, "status": "guard", "rounds": 1})
		"face":
			u.facing = action["facing"]
			events.append({"type": "face", "unit": u.id, "facing": u.facing})
		"push_boulder":
			_do_push(state, u, state.boulder_at(action["target"]), events)
		"retreat":
			_do_retreat(state, u, events)
		"emerge":
			_do_emerge(state, u, action["entrance"], events)
		"mark":
			var t := state.unit_at(action["target"])
			state.marked_id = t.id
			u.mark_used = true
			events.append({"type": "mark", "unit": u.id, "target": t.id})
	if action["type"] not in FREE_ACTIONS and action["type"] != "move":
		state.move_undo.erase(u.id)
	state.history.append(outcome)
	return outcome


# --- Validation ----------------------------------------------------------------

static func validate(state: BattleState, action: Dictionary) -> String:
	var u := state.unit(action.get("unit", ""))
	if u == null or not u.alive:
		return "no such unit"
	if not _is_units_phase(state, u):
		return "not this unit's phase"
	var t: String = action.get("type", "")
	var needs_main := t not in FREE_ACTIONS and t != "move"
	if needs_main and u.has_acted:
		return "already acted"
	if u.grappled_by_id != "" and t not in ["struggle", "skill", "wait"]:
		return "grappled"
	if u.grappling_id != "" and t not in ["reinforce", "release", "wait", "skill", "slam"]:
		return "grappling"
	match t:
		"move":
			var budget := u.move
			if u.has_acted:
				if u.post_move <= 0:
					return "cannot move now"
				budget = u.post_move
			elif u.has_moved:
				return "cannot move now"
			if not Movement.destinations(state, u, budget).has(action["to"]):
				return "unreachable"
		"undo_move":
			if not state.move_undo.has(u.id) or u.has_acted:
				return "nothing to undo"
		"skill":
			return _validate_skill(state, u, action["skill"], action["target"], action.get("to", Defs.NO_POS))
		"slam":
			if not u.has_trait("slam") or u.grappling_id == "":
				return "cannot slam"
			var held := state.unit(u.grappling_id)
			var cell: Vector2i = action["target"]
			if not state.grid.in_bounds(cell) or cell_distance(held, cell) != 1:
				return "bad slam direction"
		"grapple":
			return _validate_grapple(state, u, action["target"])
		"reinforce":
			if u.grappling_id == "":
				return "not grappling"
		"struggle":
			if u.grappled_by_id == "":
				return "not grappled"
		"release":
			if u.grappling_id == "":
				return "not grappling"
		"face":
			if u.grappled_by_id != "":
				return "facing locked"
			if not Defs.DIRS.has(action["facing"]):
				return "bad facing"
		"mark":
			if not u.has_trait("hunter_mark") or u.mark_used:
				return "cannot mark"
			var m := state.unit_at(action["target"])
			if m == null or m.team == u.team:
				return "no enemy there"
		"push_boulder":
			return _validate_push(state, u, action["target"])
		"retreat":
			if state.cave.is_empty() or state.cave["boss"] != u.id or u.hidden:
				return "cannot retreat"
			if state.open_entrances().is_empty():
				return "no open entrance"
		"emerge":
			if not u.hidden or not state.open_entrances().has(action.get("entrance", "")):
				return "cannot emerge"
		"wait":
			pass
		_:
			return "unknown action"
	return ""


static func _validate_skill(state: BattleState, u: UnitState, skill_id: String, cell: Vector2i,
		to: Vector2i = Defs.NO_POS) -> String:
	if not u.skills.has(skill_id):
		return "unknown skill"
	if u.cooldown(skill_id) > 0:
		return "on cooldown"
	if u.has_status("feared"):
		return "feared"
	if u.grappling_id != "":
		return "grappling"
	var sk := SkillCatalog.get_skill(skill_id)
	if sk.has("area_status"):
		if u.grappled_by_id != "":
			return "grappled"
		return "" if not area_targets(state, u, sk).is_empty() else "no one in range"
	if sk.has("leap"):
		if u.grappled_by_id != "":
			return "grappled"
		if to == Defs.NO_POS:
			return "need landing"
		var err := leap_landing_error(state, u, to, sk)
		if err != "":
			return err
		var sim := state.copy()
		var su := sim.unit(u.id)
		su.pos = to
		return _validate_shot(sim, su, sk, cell)
	return _validate_shot(state, u, sk, cell)


## Opponents caught by an area skill centred on the user (e.g. the lion's roar).
static func area_targets(state: BattleState, u: UnitState, sk: Dictionary) -> Array[UnitState]:
	var out: Array[UnitState] = []
	for o in state.living():
		if o.team != u.team and o.team != Defs.Team.NEUTRAL and not o.hidden and distance(u, o) <= int(sk["radius"]):
			out.append(o)
	return out


## Where a leap skill may land: within `leap` tiles, at most `leap_rise` levels up, free to stand on.
static func leap_landing_error(state: BattleState, u: UnitState, to: Vector2i, sk: Dictionary) -> String:
	if not state.footprint_in_bounds(to, u.size):
		return "bad landing"
	var d := absi(to.x - u.pos.x) + absi(to.y - u.pos.y)
	if d < 1 or d > int(sk["leap"]):
		return "bad landing"
	for c in u.footprint(to):
		if state.grid.terrain_at(c) == Defs.Terrain.DEEP:
			return "bad landing"
	if not state.blockers(to, u.size, u).is_empty() or state.boulder_in(to, u.size):
		return "bad landing"
	var rise := state.standing_height(to, u.size) - state.unit_height(u)
	if rise > int(sk.get("leap_rise", 0)) or -rise > Defs.MAX_DROP:
		return "bad landing"
	return ""


static func _validate_shot(state: BattleState, u: UnitState, sk: Dictionary, cell: Vector2i) -> String:
	var target := state.unit_at(cell) if state.grid.in_bounds(cell) else null
	if target == null or target.team == u.team:
		return "no enemy there"
	var ranged: bool = sk.get("ranged", false)
	if u.grappled_by_id != "" and (target.id != u.grappled_by_id or ranged):
		return "grappled: can only strike the grappler"
	var dist := distance(u, target)
	var min_r: int = sk["min_range"]
	var max_r: int = sk["max_range"]
	if ranged:
		if state.unit_height(u) - state.unit_height(target) >= Defs.HIGH_GROUND_RANGE_LEVELS:
			max_r += 1
		if u.has_trait("hunter_mark") and state.marked_id == target.id:
			max_r += Defs.MARK_RANGE_BONUS
		if u.has_trait("cannot_attack_adjacent"):
			min_r = maxi(min_r, 2)
	if dist < min_r or dist > max_r:
		return "out of range"
	if sk.get("shape", "single") == "line" and not _in_line(u, target):
		return "not in line"
	if ranged and not line_of_sight(state, u, target):
		return "no line of sight"
	return ""


static func _validate_grapple(state: BattleState, u: UnitState, cell: Vector2i) -> String:
	if not u.has_trait("grapple"):
		return "cannot grapple"
	var t := state.unit_at(cell) if state.grid.in_bounds(cell) else null
	if t == null or t.team == u.team:
		return "no enemy there"
	if distance(u, t) != 1:
		return "not adjacent"
	if t.has_trait("flying") or t.has_status("petrified") or t.size >= 3:
		return "cannot grapple that"
	if t.grappled_by_id != "":
		return "already grappled"
	return ""


# --- Execution -----------------------------------------------------------------

static func _do_move(state: BattleState, u: UnitState, to: Vector2i, events: Array) -> void:
	var post_move := u.has_acted  # skirmish move after acting: spends the bonus, cannot be undone
	var reach := Movement.reachable(state, u, u.post_move if post_move else -1)
	var path := Movement.path_to(reach, u.pos, to)
	if post_move:
		u.post_move = 0
	else:
		state.move_undo[u.id] = {"pos": u.pos, "facing": u.facing}
	var prev := u.pos
	for step in path:
		u.facing = step - prev
		prev = step
	events.append({"type": "move", "unit": u.id, "from": u.pos, "to": to, "path": path})
	u.pos = to
	u.has_moved = true


static func _do_undo_move(state: BattleState, u: UnitState, events: Array) -> void:
	var snap: Dictionary = state.move_undo[u.id]
	events.append({"type": "undo_move", "unit": u.id, "from": u.pos, "to": snap["pos"]})
	u.pos = snap["pos"]
	u.facing = snap["facing"]
	u.has_moved = false
	state.move_undo.erase(u.id)


static func _do_skill(state: BattleState, u: UnitState, action: Dictionary, events: Array) -> void:
	var skill_id: String = action["skill"]
	var sk := SkillCatalog.get_skill(skill_id)
	if sk.has("area_status"):
		u.has_acted = true
		if int(sk.get("cooldown", 0)) > 0:
			u.cooldowns[skill_id] = int(sk["cooldown"])
		events.append({"type": "area", "unit": u.id, "skill": skill_id})
		for o in area_targets(state, u, sk):
			Effects.add_status(state, o, sk["area_status"], int(sk.get("rounds", 1)), events)
		return
	if sk.has("leap"):
		var to: Vector2i = action["to"]
		events.append({"type": "leap", "unit": u.id, "from": u.pos, "to": to})
		u.pos = to
		u.has_moved = true
	var target := _interceptor(state, u, state.unit_at(action["target"]), events)
	var ranged: bool = sk.get("ranged", false)
	u.facing = _dir_toward(u, target)
	u.has_acted = true
	var cd: int = sk.get("cooldown", 0)
	if cd > 0:
		u.cooldowns[skill_id] = cd

	var hit := Damage.compute(state, u, target, sk["mult"], sk["type"], ranged)
	events.append({"type": "attack", "unit": u.id, "target": target.id, "skill": skill_id,
		"relation": hit["relation"], "notes": hit["notes"]})
	var dodged := target.has_status("dodge")
	Effects.deal(state, target, hit["amount"], sk["type"], skill_id, events)
	if not dodged:
		var stagger := Damage.stagger_from_relation(hit["relation"]) + int(sk.get("stagger_bonus", 0))
		if state.marked_id == target.id and hit["relation"] != Defs.Relation.FRONT:
			stagger += int(sk.get("marked_flank_stagger", 0))
		Effects.add_stagger(target, stagger, events)
	if u.has_trait("skirmish"):
		u.post_move = Defs.SKIRMISH_MOVE

	if target.alive and u.team == Defs.Team.PLAYER:
		_assist(state, u, target, events)
	var kb: int = sk.get("knockback", 0)
	if kb > 0 and target.alive and not dodged:
		Effects.knockback(state, target, _dir_toward(u, target), kb, skill_id, events)


# --- Cave and boulders (docs/09 1-5) -----------------------------------------------

static func _validate_push(state: BattleState, u: UnitState, cell: Vector2i) -> String:
	var id := state.boulder_at(cell)
	if id == "":
		return "no boulder there"
	if cell_distance(u, cell) != 1:
		return "not adjacent"
	var b: Dictionary = state.cave["boulders"][id]
	var open := state.open_entrances()
	if not open.has(b["seals"]):
		return "already sealed"
	if open.size() <= 1:
		return "cannot seal the last entrance"
	return ""


## A strong unit (Heracles) rolls a boulder home in one push; anyone else needs two.
static func _do_push(state: BattleState, u: UnitState, id: String, events: Array) -> void:
	var b: Dictionary = state.cave["boulders"][id]
	b["progress"] += 2 if u.has_trait("strong") else 1
	u.has_acted = true
	events.append({"type": "push", "unit": u.id, "boulder": id, "progress": b["progress"]})
	if b["progress"] >= 2:
		b["placed"] = true
		state.cave["entrances"][b["seals"]]["sealed"] = true
		events.append({"type": "sealed", "entrance": b["seals"], "boulder": id})


static func _do_retreat(state: BattleState, u: UnitState, events: Array) -> void:
	u.hidden = true
	u.has_moved = true
	u.has_acted = true
	u.actions_left = 1  # ends the turn
	state.cave["last"] = "retreat"
	if state.marked_id == u.id:
		state.marked_id = ""
	events.append({"type": "retreat", "unit": u.id})


## Bursts out next to the entrance (nearest free footprint), pounce ready, with `emerge_actions` left.
static func _do_emerge(state: BattleState, u: UnitState, entrance: String, events: Array) -> void:
	var want: Vector2i = state.cave["entrances"][entrance]["anchor"]
	var best := want
	var best_d := 1 << 30
	for y in state.grid.depth:
		for x in state.grid.width:
			var a := Vector2i(x, y)
			var d := absi(a.x - want.x) + absi(a.y - want.y)
			if d >= best_d or not state.footprint_in_bounds(a, u.size) or state.boulder_in(a, u.size):
				continue
			if not state.blockers(a, u.size, u).is_empty():
				continue
			best = a
			best_d = d
	u.hidden = false
	u.pos = best
	u.has_moved = false
	u.has_acted = true
	u.actions_left = int(state.cave.get("emerge_actions", 1)) + 1
	for sk in u.skills:
		if SkillCatalog.get_skill(sk).has("leap"):
			u.cooldowns.erase(sk)
	state.cave["last"] = "emerge"
	events.append({"type": "emerge", "unit": u.id, "entrance": entrance, "to": best})


## 截击: an ally with "intercept" next to the target takes the hit instead (once per round).
static func _interceptor(state: BattleState, attacker: UnitState, target: UnitState, events: Array) -> UnitState:
	if attacker.team == target.team:
		return target
	for ally in state.living(target.team):
		if ally == target or not ally.has_trait("intercept") or ally.intercept_used:
			continue
		if ally.grappling_id != "" or ally.grappled_by_id != "" or ally.has_status("stunned"):
			continue
		if distance(ally, target) != 1:
			continue
		ally.intercept_used = true
		events.append({"type": "intercept", "unit": ally.id, "protected": target.id})
		return ally
	return target


static func _do_slam(state: BattleState, u: UnitState, cell: Vector2i, events: Array) -> void:
	var held := state.unit(u.grappling_id)
	var d := Vector2(cell) + Vector2(0.5, 0.5) - held.center()
	var dir := Defs.NORTH
	if absf(d.x) >= absf(d.y):
		dir = Defs.EAST if d.x > 0.0 else Defs.WEST
	else:
		dir = Defs.SOUTH if d.y > 0.0 else Defs.NORTH
	u.has_acted = true
	events.append({"type": "slam", "unit": u.id, "target": held.id})
	Effects.end_grapple(state, u, events, "slam")
	Effects.knockback(state, held, dir, 1, "slam", events)


## One adjacent ally (first in unit order) adds a 30% follow-up, once per round each.
static func _assist(state: BattleState, attacker: UnitState, target: UnitState, events: Array) -> void:
	for ally in state.living(attacker.team):
		if ally == attacker or ally.assist_used or ally.has_status("stunned"):
			continue
		if ally.grappling_id != "" or ally.grappled_by_id != "":
			continue
		if distance(ally, target) != 1:
			continue
		ally.assist_used = true
		var hit := Damage.compute(state, ally, target, Defs.ASSIST_MULT, Defs.DamageType.PHYSICAL, false)
		events.append({"type": "assist", "unit": ally.id, "target": target.id, "relation": hit["relation"]})
		var dodged := target.has_status("dodge")
		Effects.deal(state, target, hit["amount"], Defs.DamageType.PHYSICAL, "assist", events)
		if not dodged:
			Effects.add_stagger(target, Damage.stagger_from_relation(hit["relation"]), events)
		return


static func _do_grapple(state: BattleState, u: UnitState, t: UnitState, events: Array) -> void:
	u.has_acted = true
	u.grappling_id = t.id
	t.grappled_by_id = u.id
	t.escape = Effects.escape_value(u, t)
	t.facing = _dir_toward(t, u)
	u.facing = _dir_toward(u, t)
	events.append({"type": "grapple_start", "grappler": u.id, "target": t.id, "escape": t.escape})


# --- Phase flow ----------------------------------------------------------------

## Starts the battle: player phase of round 1.
static func start_battle(state: BattleState) -> void:
	Movement.clear_cache()
	state.round_number = 1
	_begin_phase(state, Defs.Phase.PLAYER, [])


## Ends the current phase. After the enemy phase the round settles and a new round begins.
## Returns the events produced (settlement, stun skips...).
static func end_phase(state: BattleState) -> Array:
	var events: Array = []
	if state.phase == Defs.Phase.PLAYER:
		_begin_phase(state, Defs.Phase.ENEMY, events)
	else:
		settle_round(state, events)
		state.round_number += 1
		_begin_phase(state, Defs.Phase.PLAYER, events)
	state.history.append({"ok": true, "action": {"type": "end_phase"}, "events": events})
	return events


## For multi-action units (bosses): spend one activation and refresh move/act if any remain.
## Returns true if the unit may act again this phase.
static func finish_activation(state: BattleState, u: UnitState) -> bool:
	u.actions_left -= 1
	state.move_undo.erase(u.id)
	if u.actions_left > 0 and u.alive:
		u.has_moved = false
		u.has_acted = false
		return true
	u.has_moved = true
	u.has_acted = true
	return false


static func _begin_phase(state: BattleState, phase: int, events: Array) -> void:
	state.phase = phase
	state.move_undo.clear()
	var team := Defs.Team.PLAYER if phase == Defs.Phase.PLAYER else Defs.Team.ENEMY
	for u in state.living():
		if phase == Defs.Phase.PLAYER:
			u.assist_used = false
			u.mark_used = false
			u.intercept_used = false
		if u.team != team:
			continue
		u.statuses.erase("guard")
		u.statuses.erase("dodge")
		u.post_move = 0
		u.has_moved = false
		u.has_acted = false
		u.actions_left = u.actions_per_turn
		if u.has_status("stunned"):
			u.statuses.erase("stunned")
			u.has_moved = true
			u.has_acted = true
			u.actions_left = 0
			events.append({"type": "stun_skip", "unit": u.id})


## Round-end settlement order: grapples (choke, stagger, escape countdown) → terrain and
## damage-over-time → status countdown → cooldowns.
static func settle_round(state: BattleState, events: Array) -> void:
	for g in state.living():
		if g.grappling_id == "":
			continue
		var t := state.unit(g.grappling_id)
		var choke := int(g.traits["grapple"]) + (Defs.IRON_ARM_CHOKE if g.has_trait("iron_arm") else 0)
		events.append({"type": "choke", "grappler": g.id, "target": t.id, "amount": choke})
		Effects.deal(state, t, choke, Defs.DamageType.TRUE, "choke", events, false)
		if not t.alive:
			continue
		Effects.add_stagger(t, Defs.STAGGER_GRAPPLE_TICK, events)
		t.escape -= 1
		events.append({"type": "escape_tick", "target": t.id, "escape": t.escape})
		if t.escape <= 0:
			Effects.end_grapple(state, g, events, "escaped")

	for u in state.living():
		var terrain := state.grid.terrain_at(u.pos)
		if terrain == Defs.Terrain.BURNING:
			Effects.add_status(state, u, "burning", 2, events)
		elif terrain == Defs.Terrain.SWAMP:
			Effects.add_status(state, u, "poisoned", 3, events)
		elif terrain == Defs.Terrain.STYX and not u.has_trait("undead"):
			Effects.deal(state, u, Defs.STYX_DAMAGE, Defs.DamageType.TRUE, "styx", events, false)
		if u.alive and u.has_status("burning"):
			Effects.deal(state, u, Defs.BURN_DAMAGE, Defs.DamageType.TRUE, "burning", events, false)
		if u.alive and u.has_status("poisoned"):
			Effects.deal(state, u, Defs.POISON_DAMAGE, Defs.DamageType.TRUE, "poisoned", events, false)

	for u in state.living():
		for s in u.statuses.keys():
			if s in ["guard", "dodge", "stunned"]:
				continue  # cleared at the owner's next phase start
			var left: int = int(u.statuses[s]) - 1
			if left <= 0:
				u.statuses.erase(s)
				events.append({"type": "status_end", "target": u.id, "status": s})
				if s in ["feared", "rooted"]:
					u.statuses["control_immune"] = 1
			else:
				u.statuses[s] = left
		for k in u.cooldowns.keys():
			u.cooldowns[k] = maxi(0, int(u.cooldowns[k]) - 1)


# --- Geometry helpers ----------------------------------------------------------

## Manhattan distance from a unit's footprint to a cell.
static func cell_distance(u: UnitState, c: Vector2i) -> int:
	var best := 1 << 30
	for f in u.footprint():
		best = mini(best, absi(f.x - c.x) + absi(f.y - c.y))
	return best


## Manhattan distance between the closest cells of two footprints.
static func distance(a: UnitState, b: UnitState) -> int:
	var best := 1 << 30
	for ca in a.footprint():
		for cb in b.footprint():
			best = mini(best, absi(ca.x - cb.x) + absi(ca.y - cb.y))
	return best


static func line_of_sight(state: BattleState, a: UnitState, b: UnitState) -> bool:
	var from := a.pos
	var to := b.pos
	var limit := maxi(state.unit_height(a), state.unit_height(b)) + Defs.LOS_BLOCK_LEVELS - 1
	var steps := maxi(absi(to.x - from.x), absi(to.y - from.y))
	for i in range(1, steps):
		var t := float(i) / steps
		var c := Vector2i(roundi(lerpf(from.x, to.x, t)), roundi(lerpf(from.y, to.y, t)))
		if a.occupies(c) or b.occupies(c):
			continue
		if state.grid.height_at(c) > limit:
			return false
	return true


static func _in_line(a: UnitState, b: UnitState) -> bool:
	for ca in a.footprint():
		for cb in b.footprint():
			if ca.x == cb.x or ca.y == cb.y:
				return true
	return false


## Cardinal direction from `a` toward `b`, by the dominant axis between centers.
static func _dir_toward(a: UnitState, b: UnitState) -> Vector2i:
	var d := b.center() - a.center()
	if absf(d.x) >= absf(d.y):
		return Defs.EAST if d.x >= 0.0 else Defs.WEST
	return Defs.SOUTH if d.y >= 0.0 else Defs.NORTH


static func _is_units_phase(state: BattleState, u: UnitState) -> bool:
	if state.phase == Defs.Phase.PLAYER:
		return u.team == Defs.Team.PLAYER
	return u.team == Defs.Team.ENEMY
