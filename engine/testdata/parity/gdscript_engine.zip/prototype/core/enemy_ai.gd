class_name EnemyAI
extends RefCounted
## Deterministic enemy AI (docs/07 §9.3).
##
## One activation = optional move + one action. Scoring, in order of weight:
##   knock-out (+1000) > damage dealt (×10, including falls / collisions from pushes)
##   > isolated target (+15) > low target defence (−2 per point) > shorter move (−0.1 per step).
## When nothing is in reach, the unit walks the real shortest path toward the most attractive
## target (cliffs and ramps respected), not the straight-line nearest one.
## Ties keep the first candidate in row-then-column anchor order, then skill and unit order.
##
## A plan: {"move_to": Vector2i (optional), "action": Dictionary}.

const KO_SCORE := 1000.0
const DAMAGE_WEIGHT := 10.0
const ISOLATED_BONUS := 15.0
const DEFENSE_WEIGHT := 2.0
const STEP_COST := 0.1
const APPROACH_ISOLATED := 4.0  ## path-cost discount when picking whom to walk toward
const FEAR_SCORE := 14.0  ## per opponent caught by an area control skill (roar)


static func plan(state: BattleState, u: UnitState) -> Dictionary:
	var sim := _as_acting(state, u)
	var su := sim.unit(u.id)

	if su.grappled_by_id != "":
		var g := sim.unit(su.grappled_by_id)
		for sk in su.skills:
			var act := _skill(su, sk, g.pos)
			if Rules.validate(sim, act) == "" and _kills(Rules.preview(sim, act), g.id):
				return {"action": act}
		return {"action": {"type": "struggle", "unit": su.id}}

	var lair := cave_action(sim, su)
	if not lair.is_empty():
		return {"action": lair}
	if su.hidden:
		return {"action": {"type": "wait", "unit": su.id}}

	var reach: Dictionary = {su.pos: {"cost": 0}} if su.has_moved else Movement.destinations(sim, su)
	var anchors := reach.keys()
	anchors.sort_custom(_cell_less)

	var best := {}
	var best_score := -INF
	var home := su.pos
	var was_moved := su.has_moved
	for anchor in anchors:
		# Validate in place; copy the state only for attacks that are actually possible.
		su.pos = anchor
		su.has_moved = true
		for sk in su.skills:
			var def := SkillCatalog.get_skill(sk)
			if def.has("area_status"):
				var roar := _skill(su, sk, anchor)
				if Rules.validate(sim, roar) == "":
					var caught := 0
					for t in Rules.area_targets(sim, su, def):
						if not t.has_status("control_immune") and not t.has_status(def["area_status"]):
							caught += 1
					var fear := caught * FEAR_SCORE - float(reach[anchor]["cost"]) * STEP_COST
					if caught > 0 and fear > best_score:
						best_score = fear
						best = {"move_to": anchor, "action": roar}
				continue
			if def.has("leap"):
				continue  # a leap is its own move: handled below, from the starting cell only
			for t in _opponents(sim, su):
				var act := _skill(su, sk, t.pos)
				if Rules.validate(sim, act) != "":
					continue
				var o := Rules.preview(sim, act)
				var score := score_attack(sim, o, t) - float(reach[anchor]["cost"]) * STEP_COST
				if score > best_score:
					best_score = score
					best = {"move_to": anchor, "action": act}
	su.pos = home
	su.has_moved = was_moved
	if not was_moved and su.grappling_id == "":
		for sk in su.skills:
			var def := SkillCatalog.get_skill(sk)
			if not def.has("leap") or su.cooldown(sk) > 0:
				continue
			var span := int(def["leap"])
			for dy in range(-span, span + 1):
				for dx in range(-span, span + 1):
					var to := home + Vector2i(dx, dy)
					if Rules.leap_landing_error(sim, su, to, def) != "":
						continue
					for t in _opponents(sim, su):
						if _footprint_distance(su, to, t) > int(def["max_range"]):
							continue
						var act := {"type": "skill", "unit": su.id, "skill": sk, "target": t.pos, "to": to}
						if Rules.validate(sim, act) != "":
							continue
						var score := score_attack(sim, Rules.preview(sim, act), t) + 0.5  # prefers a pounce over walking in
						if score > best_score:
							best_score = score
							best = {"move_to": home, "action": act}
	if not best.is_empty():
		if best["move_to"] == su.pos:
			best.erase("move_to")
		return best

	var out := {"action": {"type": "wait", "unit": su.id}}
	if not su.has_moved:
		var goal := approach_step(sim, su)
		if goal != su.pos:
			out["move_to"] = goal
	return out


## Lair behaviour of a cave boss (docs/09 1-5, second phase). Returns an action or {}.
##   hidden            -> burst out of the open entrance nearest the softest player
##   hp <= trigger_hp  -> at the start of its phase, if it did not come out this round, go back in
static func cave_action(state: BattleState, u: UnitState) -> Dictionary:
	if state.cave.is_empty() or state.cave["boss"] != u.id:
		return {}
	if u.hidden:
		var entrance := cave_entrance(state, u)
		return {"type": "emerge", "unit": u.id, "entrance": entrance} if entrance != "" else {}
	if u.hp > int(state.cave["trigger_hp"]) or u.grappled_by_id != "" or u.has_acted or u.has_moved:
		return {}
	if u.actions_left != u.actions_per_turn or state.open_entrances().is_empty():
		return {}
	return {"type": "retreat", "unit": u.id}


## The entrance the boss will use next: the open one nearest the lowest-defence player (ties: id order).
static func cave_entrance(state: BattleState, u: UnitState) -> String:
	var prey: UnitState = null
	for t in _opponents(state, u):
		if prey == null or t.defense < prey.defense:
			prey = t
	var best := ""
	var best_d := 1 << 30
	for id in state.open_entrances():
		var a: Vector2i = state.cave["entrances"][id]["anchor"]
		var d := 0 if prey == null else absi(a.x - prey.pos.x) + absi(a.y - prey.pos.y)
		if d < best_d:
			best_d = d
			best = id
	return best


## Score of an attack outcome against its intended target. Damage counts everything the
## intended target loses (hit, push collision, fall), so pushing someone off a cliff scores high.
static func score_attack(state: BattleState, outcome: Dictionary, t: UnitState) -> float:
	var dmg := 0
	var ko := false
	for e in outcome["events"]:
		if e["type"] == "damage" and e["target"] == t.id:
			dmg += int(e["amount"])
		elif e["type"] == "ko" and e["target"] == t.id:
			ko = true
	var score := dmg * DAMAGE_WEIGHT - t.defense * DEFENSE_WEIGHT
	if ko:
		score += KO_SCORE
	if is_isolated(state, t):
		score += ISOLATED_BONUS
	return score


## Furthest stop along the real shortest path toward the best opponent to engage.
static func approach_step(state: BattleState, u: UnitState) -> Vector2i:
	var full := Movement.reachable(state, u, 999)
	var goal := Defs.NO_POS
	var goal_val := INF
	var anchors := full.keys()
	anchors.sort_custom(_cell_less)
	var opponents := _opponents(state, u)
	for anchor in anchors:
		if not full[anchor]["stop"]:
			continue
		for t in opponents:
			if _footprint_distance(u, anchor, t) != 1:
				continue
			var val := float(full[anchor]["cost"]) + t.defense * 0.5
			if is_isolated(state, t):
				val -= APPROACH_ISOLATED
			if val < goal_val:
				goal_val = val
				goal = anchor
	if goal == Defs.NO_POS:
		return u.pos
	var dests := Movement.destinations(state, u)
	var step := u.pos
	for cell in Movement.path_to(full, u.pos, goal):
		if dests.has(cell):
			step = cell
	return step


static func is_isolated(state: BattleState, t: UnitState) -> bool:
	for ally in state.living(t.team):
		if ally != t and Rules.distance(ally, t) == 1:
			return false
	return true


## Plays a plan on a copy and returns {"plan", "events"} — used for intent previews.
static func simulate(state: BattleState, u: UnitState) -> Dictionary:
	var sim := _as_acting(state, u)
	var p := plan(sim, sim.unit(u.id))
	var events: Array = []
	if p.has("move_to"):
		events.append_array(Rules.perform(sim, {"type": "move", "unit": u.id, "to": p["move_to"]})["events"])
	events.append_array(Rules.perform(sim, p["action"])["events"])
	return {"plan": p, "events": events}


## Cells this unit could hit next activation (move + any skill), ignoring line of sight.
static func threat_cells(state: BattleState, u: UnitState) -> Array[Vector2i]:
	var sim := _as_acting(state, u)
	var su := sim.unit(u.id)
	su.has_moved = false
	var seen := {}
	for anchor in Movement.destinations(sim, su):
		for sk in su.skills:
			var d := SkillCatalog.get_skill(sk)
			var min_r: int = d.get("min_range", 0)
			var max_r: int = int(d.get("max_range", d.get("radius", 1))) + int(d.get("leap", 0))
			var line: bool = d.get("shape", "single") == "line"
			for f in su.footprint(anchor):
				for dy in range(-max_r, max_r + 1):
					for dx in range(-max_r, max_r + 1):
						var dist := absi(dx) + absi(dy)
						if dist < min_r or dist > max_r or (line and dx != 0 and dy != 0):
							continue
						var c: Vector2i = f + Vector2i(dx, dy)
						if sim.grid.in_bounds(c):
							seen[c] = true
	var out: Array[Vector2i] = []
	for c in seen:
		out.append(c)
	return out


## Copy of the state in which `u` may act now (its phase, flags reset if it is not its turn).
static func _as_acting(state: BattleState, u: UnitState) -> BattleState:
	var sim := state.copy()
	var own_phase := Defs.Phase.ENEMY if u.team == Defs.Team.ENEMY else Defs.Phase.PLAYER
	if sim.phase != own_phase:
		sim.phase = own_phase
		var su := sim.unit(u.id)
		su.has_moved = false
		su.has_acted = false
	return sim


static func _skill(u: UnitState, skill_id: String, cell: Vector2i) -> Dictionary:
	return {"type": "skill", "unit": u.id, "skill": skill_id, "target": cell}


static func _kills(outcome: Dictionary, target_id: String) -> bool:
	for e in outcome["events"]:
		if e["type"] == "ko" and e["target"] == target_id:
			return true
	return false


static func _opponents(state: BattleState, u: UnitState) -> Array[UnitState]:
	var out: Array[UnitState] = []
	for o in state.living():
		if o.team != u.team and o.team != Defs.Team.NEUTRAL and not o.hidden:
			out.append(o)
	return out


static func _footprint_distance(u: UnitState, anchor: Vector2i, t: UnitState) -> int:
	var best := 1 << 30
	for a in u.footprint(anchor):
		for b in t.footprint():
			best = mini(best, absi(a.x - b.x) + absi(a.y - b.y))
	return best


static func _cell_less(a: Vector2i, b: Vector2i) -> bool:
	return a.y < b.y or (a.y == b.y and a.x < b.x)
