class_name Evaluator
extends RefCounted
## Static evaluation of a battle state from the player's side, for the player bots.
## Higher is better. Terms (weights in WEIGHTS, overridable per bot profile):
##   enemy HP lost (scaled by enemy toughness), enemy KOs, boss stagger progress, enemies held,
##   own HP kept, own KOs (hero counts much more), danger = expected damage from enemies whose
##   real threat area covers us, and a small pull toward the nearest enemy so bots engage.

const WEIGHTS := {
	"enemy_hp": 10.0,
	"enemy_ko": 8.0,
	"stagger": 6.0,
	"held": 2.0,
	"player_hp": 6.0,
	"player_ko": 25.0,
	"hero_ko": 100.0,
	"danger": 5.0,
	"distance": 0.15,
}

## enemy id -> {anchor: {cell: true}}: the cells an enemy standing there can hit next turn.
## Cleared at the start of each player turn.
static var _threat_cache := {}
## enemy id -> {player id: expected damage of its best hit}. Stats do not change within a turn.
static var _hit_cache := {}


static func begin_turn() -> void:
	_threat_cache.clear()
	_hit_cache.clear()


## The value of a state = material() + positional().
##   material   — who is hurt, down, staggered or held: changes only when a rule is applied
##   positional — danger and closing distance: the only part that changes when one of our units
##                stands somewhere else, so candidate cells can be compared without re-scoring the rest
static func score(s: BattleState, w: Dictionary = WEIGHTS) -> float:
	return material(s, w) + positional(s, w)


static func material(s: BattleState, w: Dictionary = WEIGHTS) -> float:
	var v := 0.0
	for id in s.order:
		var u: UnitState = s.units[id]
		if u.team == Defs.Team.ENEMY:
			var toughness := u.max_hp / 20.0
			v += w["enemy_hp"] * toughness * float(u.max_hp - maxi(u.hp, 0)) / u.max_hp
			if not u.alive:
				v += w["enemy_ko"] * toughness
				continue
			if u.is_boss():
				v += w["stagger"] * (1.0 if u.has_status("staggered") else float(u.stagger) / u.stagger_max)
			if u.grappled_by_id != "":
				v += w["held"]
				# A hold that survives one struggle (escape >= 2) will choke at round end: credit it now,
				# otherwise search never sees the delayed payoff and under-uses grapples.
				var g := s.unit(u.grappled_by_id)
				if g != null and g.alive and u.escape >= 2:
					var choke := int(g.traits.get("grapple", 0)) + (Defs.IRON_ARM_CHOKE if g.has_trait("iron_arm") else 0)
					v += w["enemy_hp"] * toughness * float(mini(choke, maxi(u.hp, 0))) / u.max_hp
		elif u.team == Defs.Team.PLAYER:
			if not u.alive:
				v -= w["hero_ko"] if u.id == "hero" else w["player_ko"]
				continue
			v += w["player_hp"] * float(u.hp) / u.max_hp
	# Sealing a lair entrance makes the boss predictable: worth a little on its own.
	if not s.cave.is_empty():
		for id in s.cave["boulders"]:
			var b: Dictionary = s.cave["boulders"][id]
			v += w.get("seal", 4.0) * (1.0 if b["placed"] else 0.4 * b["progress"])
	return v


static func positional(s: BattleState, w: Dictionary = WEIGHTS) -> float:
	var players: Array[UnitState] = []
	var enemies: Array[UnitState] = []
	for id in s.order:
		var u: UnitState = s.units[id]
		if not u.alive or u.hidden:
			continue
		if u.team == Defs.Team.PLAYER:
			players.append(u)
		elif u.team == Defs.Team.ENEMY:
			enemies.append(u)
	if enemies.is_empty():
		return 0.0
	var v := 0.0
	for p in players:
		var near := 99
		for e in enemies:
			near = mini(near, Rules.distance(p, e))
		v -= w["distance"] * mini(near, 12)
	return v - w["danger"] * _danger(s, players, enemies)


## Sum over our units of (expected incoming damage / current HP), capped per unit.
## Each enemy spreads its threat evenly over the units it can reach next turn.
static func _danger(s: BattleState, players: Array[UnitState], enemies: Array[UnitState]) -> float:
	var incoming: Array[float] = []
	incoming.resize(players.size())
	incoming.fill(0.0)
	var reachable: Array[int] = []
	for e in enemies:
		if e.has_status("stunned"):
			continue
		var cells := _threat(s, e)
		reachable.clear()
		for i in players.size():
			var p := players[i]
			if e.grappled_by_id != "" and e.grappled_by_id != p.id:
				continue
			if p.size == 1:
				if cells.has(p.pos):
					reachable.append(i)
			else:
				for c in p.footprint():
					if cells.has(c):
						reachable.append(i)
						break
		for i in reachable:
			incoming[i] += _expected_hit(e, players[i]) * e.actions_per_turn / float(reachable.size())
	var total := 0.0
	for i in players.size():
		total += minf(incoming[i] / maxi(players[i].hp, 1), 1.5)
	return total


static func _expected_hit(e: UnitState, p: UnitState) -> float:
	if not _hit_cache.has(e.id):
		_hit_cache[e.id] = {}
	var per: Dictionary = _hit_cache[e.id]
	if not per.has(p.id):
		var best := 0.0
		for sk_id in e.skills:
			var sk := SkillCatalog.get_skill(sk_id)
			if not sk.has("mult"):
				continue
			var raw := Defs.floor_int(e.strength * float(sk["mult"]))
			var dmg := raw
			if sk["type"] == Defs.DamageType.PHYSICAL:
				dmg = maxi(1, raw - p.defense)
			elif sk["type"] == Defs.DamageType.DIVINE:
				dmg = maxi(1, Defs.floor_int(e.divinity * float(sk["mult"])) - p.will)
			best = maxf(best, dmg)
		per[p.id] = best
	var hit: float = per[p.id]
	return hit * Defs.GRAPPLED_ATTACK_MULT if e.grappled_by_id == p.id else hit


static func _threat(s: BattleState, e: UnitState) -> Dictionary:
	if not _threat_cache.has(e.id):
		_threat_cache[e.id] = {}
	var per: Dictionary = _threat_cache[e.id]
	if not per.has(e.pos):
		var cells := {}
		for c in EnemyAI.threat_cells(s, e):
			cells[c] = true
		per[e.pos] = cells
	return per[e.pos]
