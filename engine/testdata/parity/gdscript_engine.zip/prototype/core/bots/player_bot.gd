class_name PlayerBot
extends RefCounted
## Player-side bots for balance simulations (docs/11 §4).
##
## A plan for one unit: {"move": Vector2i (optional), "mark": Vector2i (optional), "main": action}.
## apply_plan() also makes two follow-up choices the way a sensible player would: the skirmish
## bonus move (best evaluated spot) and facing the nearest enemy.
##
## Profiles:
##   novice  — one unit at a time in roster order, softmax sampling over plan scores with a high
##             temperature; ignores marking and grappling.
##   skilled — beam search over the whole team turn (unit order and each unit's plan), small
##             seeded noise so runs differ.

const PROFILES := {
	"novice": {"search": "greedy", "temperature": 3.0, "per_unit": 6, "use_mark": false, "use_grapple": false,
		"weights": {"danger": 2.0}},
	"skilled": {"search": "beam", "beam": 6, "per_unit": 8, "noise": 0.3, "use_mark": true,
		"use_grapple": true, "weights": {}},
}


static func profile(name: String) -> Dictionary:
	assert(PROFILES.has(name), "unknown bot profile %s" % name)
	var p: Dictionary = PROFILES[name].duplicate(true)
	var w := Evaluator.WEIGHTS.duplicate()
	w.merge(p["weights"], true)
	p["weights"] = w
	p["name"] = name
	return p


## Search counters for tools/profile_battle.gd.
static var stats := {"scored_calls": 0, "memo_hits": 0, "plans": 0, "applied": 0}
static var _memo := {}  ## state signature + unit id -> scored plans, within one team turn


## Plays the whole player phase on `state`. Returns [{"unit": id, "events": Array}] in order.
static func play_turn(state: BattleState, rng: RandomNumberGenerator, prof: Dictionary) -> Array:
	Evaluator.begin_turn()
	_memo.clear()
	if prof["search"] == "beam":
		return _play_beam(state, rng, prof)
	return _play_greedy(state, rng, prof)


# --- Search ----------------------------------------------------------------------

static func _play_greedy(state: BattleState, rng: RandomNumberGenerator, prof: Dictionary) -> Array:
	var played: Array = []
	for u in state.living(Defs.Team.PLAYER):
		if not u.alive or u.has_acted:
			continue
		var scored := _scored_plans(state, u, prof)
		if scored.is_empty():
			continue
		var pick := _softmax_pick(scored, float(prof["temperature"]), rng)
		played.append({"unit": u.id, "events": apply_plan(state, u.id, scored[pick]["plan"], prof)})
	return played


static func _play_beam(state: BattleState, rng: RandomNumberGenerator, prof: Dictionary) -> Array:
	var beams: Array = [{"state": state.copy(), "steps": [], "score": Evaluator.score(state, prof["weights"])}]
	var width: int = prof["beam"]
	var per_unit: int = prof["per_unit"]
	var noise: float = prof["noise"]
	while true:
		var children: Array = []
		for node in beams:
			var s: BattleState = node["state"]
			# Different unit orders often reach the same position: expand each position once.
			var sig := s.signature()
			for u in s.living(Defs.Team.PLAYER):
				if u.has_acted:
					continue
				var key := sig + [u.id]
				stats["scored_calls"] += 1
				if _memo.has(key):
					stats["memo_hits"] += 1
				else:
					_memo[key] = _scored_plans(s, u, prof)
				var scored: Array = _memo[key]
				for i in mini(per_unit, scored.size()):
					var steps: Array = (node["steps"] as Array).duplicate()
					steps.append({"unit": u.id, "plan": scored[i]["plan"]})
					children.append({"state": scored[i]["state"], "steps": steps,
						"score": float(scored[i]["score"]) + rng.randf_range(-noise, noise)})
		if children.is_empty():
			break
		children.sort_custom(func(a, b): return a["score"] > b["score"])
		beams = children.slice(0, width)
	var played: Array = []
	for step in beams[0]["steps"]:
		played.append({"unit": step["unit"], "events": apply_plan(state, step["unit"], step["plan"], prof)})
	return played


## [{plan, state, score}] sorted best first; `state` is the copy after applying the plan.
## Move-and-wait plans are first scored in place (unit moved temporarily, no copy, no rules run);
## only the best `per_unit` candidates are then applied on a copy and rescored exactly.
static func _scored_plans(s: BattleState, u: UnitState, prof: Dictionary) -> Array:
	var rough: Array = []
	var w: Dictionary = prof["weights"]
	var material := Evaluator.material(s, w)  # unchanged by where `u` stands
	for plan in plans(s, u, prof):
		if plan["main"]["type"] == "wait" and not plan.has("mark"):
			rough.append({"plan": plan, "score": material + _position_score(s, u, plan.get("move", u.pos), prof)})
		else:
			var c := s.copy()
			apply_plan(c, u.id, plan, prof)
			stats["applied"] += 1
			rough.append({"plan": plan, "state": c, "score": Evaluator.score(c, w)})
	rough.sort_custom(func(a, b): return a["score"] > b["score"])
	var keep: int = prof.get("per_unit", 1 << 30)
	var out: Array = []
	for i in mini(keep, rough.size()):
		var e: Dictionary = rough[i]
		if not e.has("state"):
			var c := s.copy()
			apply_plan(c, u.id, e["plan"], prof)
			e = {"plan": e["plan"], "state": c, "score": Evaluator.score(c, prof["weights"])}
		out.append(e)
	if prof["search"] == "greedy":
		# Greedy sampling needs every candidate's score, not just the top K.
		for i in range(keep, rough.size()):
			out.append(rough[i])
	out.sort_custom(func(a, b): return a["score"] > b["score"])
	return out


## Positional value of `u` standing at `at`, without copying the state or running any rule.
## Add Evaluator.material(s) for a full score; to compare cells of one unit this alone is enough.
static func _position_score(s: BattleState, u: UnitState, at: Vector2i, prof: Dictionary) -> float:
	var home := u.pos
	u.pos = at
	var sc := Evaluator.positional(s, prof["weights"])
	u.pos = home
	return sc


static func _softmax_pick(scored: Array, temperature: float, rng: RandomNumberGenerator) -> int:
	var top: float = scored[0]["score"]
	var weights: Array[float] = []
	var total := 0.0
	for e in scored:
		var wgt := exp((float(e["score"]) - top) / maxf(temperature, 0.001))
		weights.append(wgt)
		total += wgt
	var r := rng.randf() * total
	for i in weights.size():
		r -= weights[i]
		if r <= 0.0:
			return i
	return weights.size() - 1


# --- Candidate plans -------------------------------------------------------------

static func plans(s: BattleState, u: UnitState, prof: Dictionary) -> Array:
	var out: Array = []
	var uid := u.id
	if u.grappled_by_id != "":
		out.append({"main": {"type": "struggle", "unit": uid}})
		for sk in u.skills:
			var act := {"type": "skill", "unit": uid, "skill": sk, "target": s.unit(u.grappled_by_id).pos}
			if Rules.validate(s, act) == "":
				out.append({"main": act})
		return out
	if u.grappling_id != "":
		out.append({"main": {"type": "reinforce", "unit": uid}})
		out.append({"main": {"type": "wait", "unit": uid}})
		if u.has_trait("slam"):
			var held := s.unit(u.grappling_id)
			for c in _ring(s, held):
				var act := {"type": "slam", "unit": uid, "target": c}
				if Rules.validate(s, act) == "":
					out.append({"main": act})
		return out

	var enemies: Array[UnitState] = []
	for e in s.living(Defs.Team.ENEMY):
		if not e.hidden:
			enemies.append(e)
	var start := u.pos
	var was_moved := u.has_moved
	var dests: Array = [start] if u.has_moved else Movement.destinations(s, u).keys()
	dests.sort_custom(func(a, b): return a.y < b.y or (a.y == b.y and a.x < b.x))
	var can_mark: bool = prof["use_mark"] and u.has_trait("hunter_mark") and not u.mark_used
	# Distance bounds per skill: most (cell, enemy) pairs are out of reach, so test that with a few
	# integer operations before running the full validation. The upper bound allows for every bonus
	# (high ground +1, hunter's mark) so nothing valid is filtered out.
	var reach := {}
	for sk in u.skills:
		var def := SkillCatalog.get_skill(sk)
		if def.has("leap") or not def.has("max_range"):
			continue
		var extra := (1 + Defs.MARK_RANGE_BONUS) if def.get("ranged", false) else 0
		reach[sk] = [int(def["min_range"]), int(def["max_range"]) + extra]
	for d in dests:
		u.pos = d
		u.has_moved = was_moved or d != start
		var move: Variant = d if d != start else null
		var dist := {}
		for e in enemies:
			dist[e.id] = Rules.distance(u, e)
		for sk in reach:
			for e in enemies:
				if dist[e.id] < reach[sk][0] or dist[e.id] > reach[sk][1]:
					continue
				var act := {"type": "skill", "unit": uid, "skill": sk, "target": e.pos}
				if Rules.validate(s, act) != "":
					continue
				out.append(_plan(move, null, act))
				if can_mark and s.marked_id != e.id:
					out.append(_plan(move, e.pos, act))
		if prof["use_grapple"] and u.has_trait("grapple"):
			for e in enemies:
				if dist[e.id] != 1:
					continue
				var act := {"type": "grapple", "unit": uid, "target": e.pos}
				if Rules.validate(s, act) == "":
					out.append(_plan(move, null, act))
		if not s.cave.is_empty():
			for id in s.cave["boulders"]:
				var push := {"type": "push_boulder", "unit": uid, "target": s.cave["boulders"][id]["pos"]}
				if Rules.validate(s, push) == "":
					out.append(_plan(move, null, push))
		out.append(_plan(move, null, {"type": "wait", "unit": uid}))
	u.pos = start
	u.has_moved = was_moved
	stats["plans"] += out.size()

	# Leap skills: from the current position only (a leap is itself the move).
	if not u.has_moved:
		for sk in u.skills:
			var def := SkillCatalog.get_skill(sk)
			if not def.has("leap") or u.cooldown(sk) > 0:
				continue
			for dy in range(-def["leap"], def["leap"] + 1):
				for dx in range(-def["leap"], def["leap"] + 1):
					var to := start + Vector2i(dx, dy)
					if Rules.leap_landing_error(s, u, to, def) != "":
						continue
					for e in enemies:
						var act := {"type": "skill", "unit": uid, "skill": sk, "target": e.pos, "to": to}
						if Rules.validate(s, act) == "":
							out.append(_plan(null, null, act))
	return out


static func _plan(move: Variant, mark: Variant, main: Dictionary) -> Dictionary:
	var p := {"main": main}
	if move != null:
		p["move"] = move
	if mark != null:
		p["mark"] = mark
	return p


static func _ring(s: BattleState, t: UnitState) -> Array[Vector2i]:
	var out: Array[Vector2i] = []
	for f in t.footprint():
		for d in Defs.DIRS:
			var c: Vector2i = f + d
			if s.grid.in_bounds(c) and not t.occupies(c) and not out.has(c):
				out.append(c)
	return out


# --- Applying a plan ---------------------------------------------------------------

## Performs the plan on `s` and returns the events. Falls back to waiting if the main action
## became invalid. Follow-ups: best skirmish move, then face the nearest enemy.
static func apply_plan(s: BattleState, uid: String, plan: Dictionary, prof: Dictionary) -> Array:
	var ev: Array = []
	var u := s.unit(uid)
	if plan.has("move"):
		ev.append_array(Rules.perform(s, {"type": "move", "unit": uid, "to": plan["move"]})["events"])
	if plan.has("mark"):
		ev.append_array(Rules.perform(s, {"type": "mark", "unit": uid, "target": plan["mark"]})["events"])
	var o := Rules.perform(s, plan["main"])
	if not o["ok"]:
		o = Rules.perform(s, {"type": "wait", "unit": uid})
	ev.append_array(o["events"])
	if u.alive and u.post_move > 0:
		var best := u.pos
		var best_score := -INF
		var dests := Movement.destinations(s, u, u.post_move).keys()
		dests.sort_custom(func(a, b): return a.y < b.y or (a.y == b.y and a.x < b.x))
		for d in dests:
			var sc := _position_score(s, u, d, prof)
			if sc > best_score:
				best_score = sc
				best = d
		if best != u.pos:
			ev.append_array(Rules.perform(s, {"type": "move", "unit": uid, "to": best})["events"])
	if u.alive and u.grappled_by_id == "" and u.grappling_id == "":
		var f := _face_nearest(s, u)
		if f != u.facing and f != Vector2i.ZERO:
			ev.append_array(Rules.perform(s, {"type": "face", "unit": uid, "facing": f})["events"])
	return ev


static func _face_nearest(s: BattleState, u: UnitState) -> Vector2i:
	var best: UnitState = null
	var best_d := 1 << 30
	for e in s.living(Defs.Team.ENEMY):
		var d := Rules.distance(u, e)
		if d < best_d:
			best_d = d
			best = e
	if best == null:
		return Vector2i.ZERO
	var v := best.center() - u.center()
	if absf(v.x) >= absf(v.y):
		return Defs.EAST if v.x >= 0.0 else Defs.WEST
	return Defs.SOUTH if v.y >= 0.0 else Defs.NORTH
