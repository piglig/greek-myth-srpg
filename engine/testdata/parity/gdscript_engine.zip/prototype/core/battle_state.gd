class_name BattleState
extends RefCounted
## Whole-battle state. Rules mutate it; the view only reads it.

var grid: BattleGrid
var units := {}  ## id -> UnitState
var order: Array[String] = []  ## insertion order, used for deterministic tie-breaks
var round_number := 1
var phase: int = Defs.Phase.PLAYER
var marked_id := ""
var history: Array = []  ## performed outcomes, oldest first
var move_undo := {}  ## unit id -> {pos, facing}
## Boss-lair state (docs/09 1-5), empty when the battle has no cave:
##   {boss, trigger_hp, emerge_actions, last ("" | "retreat" | "emerge"),
##    entrances: {id: {anchor: Vector2i, sealed: bool}},
##    boulders: {id: {pos: Vector2i, seals: entrance id, progress: int, placed: bool}}}
var cave := {}


func _init(g: BattleGrid = null) -> void:
	grid = g


func add_unit(u: UnitState) -> UnitState:
	assert(not units.has(u.id), "duplicate unit id %s" % u.id)
	units[u.id] = u
	order.append(u.id)
	return u


func unit(id: String) -> UnitState:
	return units.get(id)


func unit_at(c: Vector2i) -> UnitState:
	for id in order:
		var u: UnitState = units[id]
		if u.alive and not u.hidden and u.occupies(c):
			return u
	return null


func living(team: int = -1) -> Array[UnitState]:
	var out: Array[UnitState] = []
	for id in order:
		var u: UnitState = units[id]
		if u.alive and (team == -1 or u.team == team):
			out.append(u)
	return out


## Id of the boulder standing on cell `c` ("" if none). Boulders block movement like a wall.
func boulder_at(c: Vector2i) -> String:
	if cave.is_empty():
		return ""
	for id in cave["boulders"]:
		var b: Dictionary = cave["boulders"][id]
		if not b["placed"] and b["pos"] == c:
			return id
	return ""


func boulder_in(anchor: Vector2i, size: int) -> bool:
	if cave.is_empty():
		return false
	for dy in size:
		for dx in size:
			if boulder_at(anchor + Vector2i(dx, dy)) != "":
				return true
	return false


func open_entrances() -> Array[String]:
	var out: Array[String] = []
	if not cave.is_empty():
		for id in cave["entrances"]:
			if not cave["entrances"][id]["sealed"]:
				out.append(id)
	return out


## Standing height of a footprint = the highest cell under it.
func standing_height(anchor: Vector2i, size: int) -> int:
	var h := 0
	for dy in size:
		for dx in size:
			h = maxi(h, grid.height_at(anchor + Vector2i(dx, dy)))
	return h


func unit_height(u: UnitState) -> int:
	return standing_height(u.pos, u.size)


func footprint_in_bounds(anchor: Vector2i, size: int) -> bool:
	return grid.in_bounds(anchor) and grid.in_bounds(anchor + Vector2i(size - 1, size - 1))


## Living units other than `ignore` overlapping the footprint.
func blockers(anchor: Vector2i, size: int, ignore: UnitState) -> Array[UnitState]:
	var out: Array[UnitState] = []
	for dy in size:
		for dx in size:
			var other := unit_at(anchor + Vector2i(dx, dy))
			if other != null and other != ignore and not out.has(other):
				out.append(other)
	return out


## Everything that distinguishes two states of the same battle, as a hashable value. Two search
## branches that reach the same signature are the same position (used to share work in the bots).
func signature() -> Array:
	var sig: Array = [phase, round_number, marked_id]
	for id in order:
		var u: UnitState = units[id]
		sig.append_array([u.pos, u.hp, u.alive, u.hidden, u.facing, u.has_moved, u.has_acted, u.actions_left,
			u.stagger, u.escape, u.grappling_id, u.grappled_by_id, u.shield, u.post_move, u.mark_used,
			u.assist_used, u.intercept_used, str(u.statuses), str(u.cooldowns)])
	if not cave.is_empty():
		sig.append(str(cave))
	return sig


## Copies unit state; the grid is shared because rules never mutate it during a battle.
## Terrain changes (e.g. a bridge state swap) must replace `grid` with a modified copy.
func copy() -> BattleState:
	var s := BattleState.new(grid)
	for id in order:
		s.add_unit((units[id] as UnitState).copy())
	s.round_number = round_number
	s.phase = phase
	s.marked_id = marked_id
	s.move_undo = move_undo.duplicate(true)
	s.cave = cave.duplicate(true)
	return s
