class_name Defs
extends RefCounted
## Shared enums and tuning constants. Values follow docs/07-combat-rules.md.

enum Team { PLAYER, ENEMY, NEUTRAL }
enum Terrain { PLAIN, FOREST, SHALLOW, DEEP, SWAMP, BURNING, STYX }
enum DamageType { PHYSICAL, DIVINE, TRUE }
enum Relation { FRONT, SIDE, BACK }
enum Phase { PLAYER, ENEMY }

const NORTH := Vector2i(0, -1)
const EAST := Vector2i(1, 0)
const SOUTH := Vector2i(0, 1)
const WEST := Vector2i(-1, 0)
const DIRS := [NORTH, EAST, SOUTH, WEST]

const MAX_HEIGHT := 5
const MAX_DROP := 2
const BOSS_STRUGGLE := 2  ## escape points a boss removes per struggle (others: 1)
## A cell blocks line of sight only if it is this many levels above both shooter and target.
const LOS_BLOCK_LEVELS := 2

const SIDE_MULT := 1.25
const BACK_MULT := 1.5
const HIGH_GROUND_MULT := 1.2
const HIGH_GROUND_RANGE_LEVELS := 2
const COVER_MULT := 0.75
const BLOCK_MULT := 0.5
const GUARD_MULT := 0.7
const MARK_MULT := 1.15
const MARK_RANGE_BONUS := 2
const FLANK_MULT := 1.1
const BROKEN_MULT := 1.25
const GRAPPLED_ATTACK_MULT := 0.7
const ASSIST_MULT := 0.3
const PATIENCE_MULT := 1.25
const IRON_ARM_MULT := 0.8
const IRON_ARM_CHOKE := 3
const SHIELD_WALL_MULT := 0.85
const SKIRMISH_MOVE := 2

const FALL_DAMAGE_PER_LEVEL := 3
const COLLISION_DAMAGE := 3
const EDGE_DAMAGE := 10
const BURN_DAMAGE := 2
const POISON_DAMAGE := 2
const STYX_DAMAGE := 3

const STAGGER_BACK := 20
const STAGGER_SIDE := 10
const STAGGER_KNOCKBACK := 15
const STAGGER_FALL_PER_LEVEL := 5
const STAGGER_GRAPPLE_TICK := 15

const ESCAPE_BASE := 3
const ESCAPE_MIN := 1
const ESCAPE_MAX := 5
const ESCAPE_MAX_BOSS := 3

## Statuses that boss "super armor" ignores unless the boss is broken.
const CONTROL_STATUSES := ["stunned", "feared", "rooted"]

const EPSILON := 0.000001
const NO_POS := Vector2i(-99999, -99999)  ## sentinel for "use the unit's own position"


static func terrain_cost(terrain: int, forest_stride: bool) -> int:
	match terrain:
		Terrain.FOREST:
			return 1 if forest_stride else 2
		Terrain.SHALLOW:
			return 2
		Terrain.SWAMP:
			return 3
		Terrain.DEEP:
			return -1
		_:
			return 1


static func floor_int(value: float) -> int:
	return int(floor(value + EPSILON))
