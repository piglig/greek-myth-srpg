class_name BattleRunner
extends RefCounted
## Plays one battle headless (player bot vs EnemyAI) and returns a metrics record (docs/11 §5.1).
##
## result: "win" | "loss_hero" (hero down) | "loss_wipe" (party down) | "timeout"
## Damage is attributed to the acting unit; round-end choke goes to the grappler.

const MECHANICS := ["grapple_start", "slam", "mark", "intercept", "leap", "knockback", "broken",
	"assist", "edge", "collision", "struggle", "push", "sealed", "retreat", "emerge"]


## `on_events(state, events, actor)` is called for every batch of events (tracing, replays).
static func run(battle_id: String, picks: Dictionary, prof: Dictionary, seed: int,
		max_rounds: int = 30, on_events: Callable = Callable()) -> Dictionary:
	var t0 := Time.get_ticks_msec()
	var s := Battles.build(battle_id, picks)
	Rules.start_battle(s)
	var rng := RandomNumberGenerator.new()
	rng.seed = seed
	var m := _new_record(s, battle_id, picks, prof, seed)
	m["_hook"] = on_events

	var result := ""
	while result == "":
		for step in PlayerBot.play_turn(s, rng, prof):
			_collect(s, m, step["events"], step["unit"])
		result = _outcome(s)
		if result != "":
			break
		_collect(s, m, Rules.end_phase(s), "")
		for e in s.living(Defs.Team.ENEMY):
			var guard := 0
			while e.alive and not e.has_acted and guard < 4:
				guard += 1
				var p := EnemyAI.plan(s, e)
				if p.has("move_to"):
					_collect(s, m, Rules.perform(s, {"type": "move", "unit": e.id, "to": p["move_to"]})["events"], e.id)
				var o := Rules.perform(s, p["action"])
				if not o["ok"]:
					o = Rules.perform(s, {"type": "wait", "unit": e.id})
				_collect(s, m, o["events"], e.id)
				if not Rules.finish_activation(s, e):
					break
			result = _outcome(s)
			if result != "":
				break
		if result != "":
			break
		_collect(s, m, Rules.end_phase(s), "")
		result = _outcome(s)
		if result == "" and s.round_number > max_rounds:
			result = "timeout"

	m["result"] = result
	m["win"] = result == "win"
	m["rounds"] = s.round_number
	var hp := 0
	var max_hp := 0
	for id in s.order:
		var u: UnitState = s.units[id]
		var rec: Dictionary = m["units"][id]
		rec["hp"] = maxi(u.hp, 0) if u.alive else 0
		rec["alive"] = u.alive
		if u.team == Defs.Team.PLAYER:
			hp += rec["hp"]
			max_hp += u.max_hp
	m["party_hp_left"] = float(hp) / max_hp
	m["ms"] = Time.get_ticks_msec() - t0
	m.erase("_hook")
	return m


static func _new_record(s: BattleState, battle_id: String, picks: Dictionary, prof: Dictionary, seed: int) -> Dictionary:
	var units := {}
	for id in s.order:
		var u: UnitState = s.units[id]
		units[id] = {"def": u.def_id, "team": "player" if u.team == Defs.Team.PLAYER else "enemy",
			"max_hp": u.max_hp, "dealt": 0, "taken": 0}
	var counts := {}
	for k in MECHANICS:
		counts[k] = 0
	counts["fall_enemy"] = 0
	counts["fall_enemy_levels"] = 0
	counts["fall_player"] = 0
	counts["ko_enemy"] = 0
	counts["ko_player"] = 0
	return {"battle": battle_id, "bot": prof["name"], "seed": seed, "picks": picks, "units": units,
		"dmg_to_enemy": {}, "dmg_to_player": {}, "counts": counts,
		"falls": [],   # [{def, levels, round, from, to}] for every enemy fall
		"kills": [],   # [{def, by, source, round, pos}]: killing blow per enemy KO
		"dmg_cells": {},  # "x,y" -> damage taken by player units standing there
		"break_rounds": [],  # rounds in which a boss was broken
		"phase2_round": 0}  # round the boss first retreated into its lair (0 = never)


static func _collect(s: BattleState, m: Dictionary, events: Array, actor: String) -> void:
	var hook: Callable = m["_hook"]
	if hook.is_valid():
		hook.call(s, events, actor)
	var grappler_of := {}
	for e in events:
		if e["type"] == "choke":
			grappler_of[e["target"]] = e["grappler"]
	var last_source := {}
	var pushed_from := {}
	for e in events:
		if e["type"] == "knockback":
			pushed_from[e["target"]] = e["from"]
	for e in events:
		var t: String = e["type"]
		if t == "damage":
			last_source[e["target"]] = e["source"]
		if MECHANICS.has(t):
			m["counts"][t] += 1
		match t:
			"damage":
				var target := s.unit(e["target"])
				var src: String = e["source"]
				var amt: int = e["amount"]
				var bucket := "dmg_to_enemy" if target.team == Defs.Team.ENEMY else "dmg_to_player"
				m[bucket][src] = int(m[bucket].get(src, 0)) + amt
				m["units"][target.id]["taken"] += amt
				if target.team == Defs.Team.PLAYER:
					var cell := "%d,%d" % [target.pos.x, target.pos.y]
					m["dmg_cells"][cell] = int(m["dmg_cells"].get(cell, 0)) + amt
				var by := actor
				if src == "choke":
					by = grappler_of.get(target.id, "")
				if by != "" and s.unit(by).team != target.team:
					m["units"][by]["dealt"] += amt
			"broken":
				m["break_rounds"].append(s.round_number)
			"retreat":
				if int(m["phase2_round"]) == 0:
					m["phase2_round"] = s.round_number
			"fall":
				if s.unit(e["target"]).team == Defs.Team.ENEMY:
					m["falls"].append({"def": s.unit(e["target"]).def_id, "levels": int(e["levels"]), "round": s.round_number,
						"from": _xy(pushed_from.get(e["target"], s.unit(e["target"]).pos)), "to": _xy(s.unit(e["target"]).pos)})
					m["counts"]["fall_enemy"] += 1
					m["counts"]["fall_enemy_levels"] += int(e["levels"])
				else:
					m["counts"]["fall_player"] += 1
			"ko":
				var victim := s.unit(e["target"])
				var team_key := "ko_enemy" if victim.team == Defs.Team.ENEMY else "ko_player"
				m["counts"][team_key] += 1
				if victim.team == Defs.Team.ENEMY:
					var src: String = last_source.get(victim.id, "edge")
					var by: String = actor if src != "choke" else grappler_of.get(victim.id, "")
					m["kills"].append({"def": victim.def_id, "by": s.unit(by).def_id if by != "" else "",
						"source": src, "round": s.round_number, "pos": _xy(victim.pos)})


static func _xy(v: Vector2i) -> Array:
	return [v.x, v.y]


static func _outcome(s: BattleState) -> String:
	var hero := s.unit("hero")
	if hero == null or not hero.alive:
		return "loss_hero"
	if s.living(Defs.Team.PLAYER).is_empty():
		return "loss_wipe"
	if s.living(Defs.Team.ENEMY).is_empty():
		return "win"
	return ""
