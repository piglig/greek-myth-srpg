class_name Damage
extends RefCounted
## Damage formula (docs/07 §4). Deterministic; no random rolls anywhere.


## Facing relation of an attack coming from `from_center` against `target`.
static func relation(from_center: Vector2, target: UnitState) -> int:
	var d := from_center - target.center()
	var f := Vector2(target.facing)
	var along := d.dot(f)
	var across := absf(d.x * f.y - d.y * f.x)
	if along > 0.0 and along > across:
		return Defs.Relation.FRONT
	if along < 0.0 and -along > across:
		return Defs.Relation.BACK
	return Defs.Relation.SIDE


static func relation_mult(rel: int) -> float:
	match rel:
		Defs.Relation.BACK:
			return Defs.BACK_MULT
		Defs.Relation.SIDE:
			return Defs.SIDE_MULT
		_:
			return 1.0


## Is `target` sandwiched by units of `team` on two opposite sides?
static func is_flanked(state: BattleState, target: UnitState, team: int) -> bool:
	var s := target.size
	var p := target.pos
	var left := false
	var right := false
	var top := false
	var bottom := false
	for i in s:
		left = left or _is_team(state, p + Vector2i(-1, i), team)
		right = right or _is_team(state, p + Vector2i(s, i), team)
		top = top or _is_team(state, p + Vector2i(i, -1), team)
		bottom = bottom or _is_team(state, p + Vector2i(i, s), team)
	return (left and right) or (top and bottom)


## Computes one hit. Returns:
## {amount, relation, immune, base, mult, notes: Array[String]}
## `from_anchor` lets callers evaluate an attack from a hypothetical position.
static func compute(state: BattleState, attacker: UnitState, target: UnitState, skill_mult: float,
		dmg_type: int, ranged: bool, from_anchor: Vector2i = Defs.NO_POS) -> Dictionary:
	if from_anchor == Defs.NO_POS:
		from_anchor = attacker.pos
	var rel := relation(attacker.center(from_anchor), target)
	var notes: Array[String] = []
	var broken := target.has_status("staggered")
	if dmg_type == Defs.DamageType.PHYSICAL and target.has_trait("physical_immune") and not broken:
		return {"amount": 0, "relation": rel, "immune": true, "base": 0, "mult": 0.0,
			"notes": ["physical_immune"]}

	var stat := attacker.divinity if dmg_type == Defs.DamageType.DIVINE else attacker.strength
	var raw := Defs.floor_int(stat * skill_mult)
	var mitigation := 0
	if dmg_type == Defs.DamageType.PHYSICAL:
		mitigation = target.defense
	elif dmg_type == Defs.DamageType.DIVINE:
		mitigation = target.will
	var base := maxi(1, raw - mitigation)

	var m := relation_mult(rel)
	if rel == Defs.Relation.FRONT and target.has_trait("block"):
		m *= Defs.BLOCK_MULT
		notes.append("block")
	var h_att := state.standing_height(from_anchor, attacker.size)
	var h_tgt := state.unit_height(target)
	if h_att >= h_tgt + 1:
		m *= Defs.HIGH_GROUND_MULT
		notes.append("high_ground")
	if ranged and state.grid.terrain_at(target.pos) == Defs.Terrain.FOREST:
		m *= Defs.COVER_MULT
		notes.append("cover")
	if state.marked_id == target.id and attacker.team == Defs.Team.PLAYER:
		m *= Defs.MARK_MULT
		notes.append("marked")
	if is_flanked(state, target, attacker.team):
		m *= Defs.FLANK_MULT
		notes.append("flanked")
	if attacker.has_trait("patience") and not attacker.has_moved:
		m *= Defs.PATIENCE_MULT
		notes.append("patience")
	if target.has_trait("iron_arm") and target.grappling_id != "":
		m *= Defs.IRON_ARM_MULT
		notes.append("iron_arm")
	if _shield_wall_covers(state, target):
		m *= Defs.SHIELD_WALL_MULT
		notes.append("shield_wall")
	if target.has_status("guard"):
		m *= Defs.GUARD_MULT
		notes.append("guard")
	if broken:
		m *= Defs.BROKEN_MULT
		notes.append("broken")
	if attacker.grappled_by_id != "" and attacker.grappled_by_id == target.id:
		m *= Defs.GRAPPLED_ATTACK_MULT
		notes.append("grappled")
	return {"amount": Defs.floor_int(base * m), "relation": rel, "immune": false,
		"base": base, "mult": m, "notes": notes}


## Stagger gained by a boss from the attack's direction, even when the hit deals 0.
static func stagger_from_relation(rel: int) -> int:
	match rel:
		Defs.Relation.BACK:
			return Defs.STAGGER_BACK
		Defs.Relation.SIDE:
			return Defs.STAGGER_SIDE
		_:
			return 0


## A guarding ally with 盾墙 next to the target cuts its damage.
static func _shield_wall_covers(state: BattleState, target: UnitState) -> bool:
	for ally in state.living(target.team):
		if ally != target and ally.has_trait("shield_wall") and ally.has_status("guard") 				and Rules.distance(ally, target) == 1:
			return true
	return false


static func _is_team(state: BattleState, c: Vector2i, team: int) -> bool:
	if not state.grid.in_bounds(c):
		return false
	var u := state.unit_at(c)
	return u != null and u.team == team
