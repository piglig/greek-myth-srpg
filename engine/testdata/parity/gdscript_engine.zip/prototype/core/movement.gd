class_name Movement
extends RefCounted
## Reachability and paths (docs/07 §5.1). Costs: terrain cost + 1 per level climbed.


## cell -> UnitState for every living unit (built once per search instead of scanning units per cell).
static func occupancy(state: BattleState) -> Dictionary:
	var occ := {}
	for u in state.living():
		if u.hidden:
			continue
		for c in u.footprint():
			occ[c] = u
	return occ


## Can `u` step from anchor `a` to the adjacent anchor `b`? Returns the step cost, or -1.
## `occ` is an optional occupancy() map; pass it when calling in a loop.
static func step_cost(state: BattleState, u: UnitState, a: Vector2i, b: Vector2i, occ: Dictionary = {}) -> int:
	if not state.footprint_in_bounds(b, u.size) or state.boulder_in(b, u.size):
		return -1
	var flying := u.has_trait("flying")
	var cost := 0
	for c in u.footprint(b):
		var t := state.grid.terrain_at(c)
		var tc := Defs.terrain_cost(t, u.has_trait("forest_stride"))
		if tc < 0 and not flying:
			return -1
		cost = maxi(cost, 1 if flying else tc)
		var other: UnitState = occ.get(c) if not occ.is_empty() else state.unit_at(c)
		if other != null and other != u and other.team != u.team:
			return -1
	if flying:
		return cost
	var rise := state.standing_height(b, u.size) - state.standing_height(a, u.size)
	if rise > u.jump or -rise > Defs.MAX_DROP:
		return -1
	return cost + maxi(rise, 0)


## Every anchor the unit can pass through this turn: {anchor: {"cost", "from", "stop"}}.
## "stop" is false where another unit stands (allies can be passed, not shared).
## Use this map for path reconstruction; use destinations() for where a move may end.
static func reachable(state: BattleState, u: UnitState, budget: int = -1) -> Dictionary:
	var key := _key(state, u, budget, 0)
	if not _cache.has(key):
		if _cache.size() > CACHE_LIMIT:
			_cache.clear()
		_cache[key] = _reachable(state, u, budget)
	return _cache[key]


## Results depend only on the grid, who stands where, boulders and the mover itself, so they are
## memoized on exactly that: the bots evaluate hundreds of candidate plans from the same position
## and each used to recompute this search twice. Cached maps are shared: treat them as read-only.
const CACHE_LIMIT := 20000
static var _cache := {}


static func clear_cache() -> void:
	_cache.clear()


static func _key(state: BattleState, u: UnitState, budget: int, kind: int) -> Array:
	var key: Array = [kind, state.grid.get_instance_id(), u.id, budget, u.pos, u.move, u.jump,
		u.has_status("rooted") or u.grappling_id != "" or u.grappled_by_id != ""]
	for id in state.order:
		var o: UnitState = state.units[id]
		key.append(o.pos if o.alive and not o.hidden else Defs.NO_POS)
	if not state.cave.is_empty():
		for id in state.cave["boulders"]:
			key.append(state.cave["boulders"][id]["placed"])
	return key


static func _reachable(state: BattleState, u: UnitState, budget: int = -1) -> Dictionary:
	if budget < 0:
		budget = u.move
	var best := {u.pos: {"cost": 0, "from": u.pos, "stop": true}}
	if u.has_status("rooted") or u.grappling_id != "" or u.grappled_by_id != "":
		return best
	# Bucket queue: step costs are small positive ints. Each bucket is processed in row-then-column
	# order so equal-cost paths are chosen deterministically; stale entries are skipped.
	var occ := occupancy(state)
	var buckets := {0: [u.pos]}
	var cost := 0
	var max_cost := mini(budget, 999)
	while cost <= max_cost:
		if not buckets.has(cost):
			cost += 1
			if buckets.is_empty():
				break
			continue
		var bucket: Array = buckets[cost]
		buckets.erase(cost)
		bucket.sort_custom(func(a, b): return a.y < b.y or (a.y == b.y and a.x < b.x))
		for cur in bucket:
			if int(best[cur]["cost"]) != cost:
				continue
			for dir in Defs.DIRS:
				var nxt: Vector2i = cur + dir
				var sc := step_cost(state, u, cur, nxt, occ)
				if sc < 0:
					continue
				var nc := cost + sc
				if nc > budget:
					continue
				if not best.has(nxt) or nc < int(best[nxt]["cost"]):
					best[nxt] = {"cost": nc, "from": cur}
					if not buckets.has(nc):
						buckets[nc] = []
					buckets[nc].append(nxt)
	for anchor in best:
		var free := true
		if anchor != u.pos:
			for c in u.footprint(anchor):
				var o: UnitState = occ.get(c)
				if o != null and o != u:
					free = false
					break
		best[anchor]["stop"] = free
	return best


## Anchors a move may end on (includes the start anchor).
static func destinations(state: BattleState, u: UnitState, budget: int = -1) -> Dictionary:
	var key := _key(state, u, budget, 1)
	if not _cache.has(key):
		_cache[key] = _destinations(state, u, budget)
	return _cache[key]


static func _destinations(state: BattleState, u: UnitState, budget: int = -1) -> Dictionary:
	var out := {}
	var all := reachable(state, u, budget)
	for anchor in all:
		if all[anchor]["stop"]:
			out[anchor] = all[anchor]
	return out


static func path_to(reach: Dictionary, start: Vector2i, dest: Vector2i) -> Array[Vector2i]:
	var path: Array[Vector2i] = []
	if not reach.has(dest):
		return path
	var cur := dest
	while cur != start:
		path.push_front(cur)
		cur = reach[cur]["from"]
	return path
