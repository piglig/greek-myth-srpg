extends RefCounted
## Builders for small test battles.
##
## Rule tests must not depend on tuning: units built here get the REFERENCE stats below (the
## worked examples in docs/07–09), whatever data/tables/units.json currently says. Balance
## numbers are checked separately by the balance tooling (balance/specs, balance/targets).

const REFERENCE := {
	"hero": {"hp": 40, "str": 12, "def": 6},
	"atalanta": {"hp": 30, "str": 11, "def": 3},
	"heracles": {"hp": 60, "max_hp": 80, "str": 20, "def": 9},
	"wolf": {"hp": 16, "str": 9, "def": 1},
	"bandit": {"hp": 20, "str": 10, "def": 3},
	"bandit_archer": {"hp": 16, "str": 9, "def": 2},
	"bandit_chief": {"hp": 30, "str": 12, "def": 4},
	"boar": {"hp": 36, "str": 13, "def": 8},
	"lion": {"hp": 60, "str": 16, "def": 4},
}


static func make(def_id: String, id: String, team: int, pos: Vector2i, facing: Vector2i = Defs.SOUTH) -> UnitState:
	var u := UnitCatalog.make(def_id, id, team, pos, facing)
	var ref: Dictionary = REFERENCE.get(def_id, {})
	u.hp = ref.get("hp", u.hp)
	u.max_hp = ref.get("max_hp", ref.get("hp", u.max_hp))
	u.strength = ref.get("str", u.strength)
	u.defense = ref.get("def", u.defense)
	return u


static func state(height_rows: Array, terrain_rows: Array = []) -> BattleState:
	return BattleState.new(BattleGrid.from_rows(height_rows, terrain_rows))


static func flat(w: int = 8, d: int = 8) -> BattleState:
	var rows := []
	for i in d:
		rows.append("0".repeat(w))
	return state(rows)


static func add(s: BattleState, def_id: String, id: String, team: int, pos: Vector2i,
		facing: Vector2i = Defs.SOUTH) -> UnitState:
	return s.add_unit(make(def_id, id, team, pos, facing))


static func ally(s: BattleState, def_id: String, id: String, pos: Vector2i,
		facing: Vector2i = Defs.EAST) -> UnitState:
	return add(s, def_id, id, Defs.Team.PLAYER, pos, facing)


static func foe(s: BattleState, def_id: String, id: String, pos: Vector2i,
		facing: Vector2i = Defs.WEST) -> UnitState:
	return add(s, def_id, id, Defs.Team.ENEMY, pos, facing)


static func skill(unit_id: String, skill_id: String, target: Vector2i) -> Dictionary:
	return {"type": "skill", "unit": unit_id, "skill": skill_id, "target": target}
