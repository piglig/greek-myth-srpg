extends "res://tests/support/test_case.gd"
## Placeholder AI: deterministic plans, kill priority, struggling, threat cells.

const F := preload("res://tests/support/fixtures.gd")


func test_wolf_moves_in_and_bites() -> void:
	var s := F.flat()
	F.ally(s, "hero", "hero", Vector2i(1, 1))
	F.foe(s, "wolf", "wolf", Vector2i(5, 1))
	Rules.start_battle(s)
	Rules.end_phase(s)
	var p := EnemyAI.plan(s, s.unit("wolf"))
	check(p.has("move_to"), "moves")
	eq(p["action"]["type"], "skill", "attacks")
	eq(p["action"]["target"], Vector2i(1, 1), "targets hero")


func test_plans_are_deterministic() -> void:
	var s := Battles.build("test")
	Rules.start_battle(s)
	Rules.end_phase(s)
	for e in s.living(Defs.Team.ENEMY):
		eq(EnemyAI.plan(s, e), EnemyAI.plan(s, e), "same plan twice for " + e.id)


func test_prefers_the_kill() -> void:
	var s := F.flat()
	F.ally(s, "hero", "hero", Vector2i(1, 1))
	var ata := F.ally(s, "atalanta", "ata", Vector2i(3, 1))
	ata.hp = 5
	F.foe(s, "wolf", "wolf", Vector2i(2, 2))
	Rules.start_battle(s)
	Rules.end_phase(s)
	eq(EnemyAI.plan(s, s.unit("wolf"))["action"]["target"], Vector2i(3, 1), "finishes atalanta")


func test_grappled_enemy_struggles_unless_it_can_kill() -> void:
	var s := F.flat()
	var hero := F.ally(s, "hero", "hero", Vector2i(1, 1))
	F.foe(s, "wolf", "wolf", Vector2i(2, 1))
	Rules.start_battle(s)
	Rules.perform(s, {"type": "grapple", "unit": "hero", "target": Vector2i(2, 1)})
	Rules.end_phase(s)
	eq(EnemyAI.plan(s, s.unit("wolf"))["action"]["type"], "struggle", "struggles")
	hero.hp = 2
	eq(EnemyAI.plan(s, s.unit("wolf"))["action"]["type"], "skill", "bites the weakened grappler")


func test_intent_preview_during_player_phase_does_not_mutate() -> void:
	var s := Battles.build("test")
	Rules.start_battle(s)
	var wolf := s.unit("wolf_a")
	var before := wolf.pos
	var sim := EnemyAI.simulate(s, wolf)
	check(not (sim["events"] as Array).is_empty(), "has events")
	eq(wolf.pos, before, "real wolf untouched")
	eq(s.phase, Defs.Phase.PLAYER, "phase untouched")
	check(EnemyAI.threat_cells(s, wolf).size() > 10, "threat area")


func test_boar_takes_the_ramp_instead_of_waiting_at_the_cliff() -> void:
	# Plateau (height 3) on the left; the only way down is the single-step ramp in rows 3-4.
	var s := F.state([
		"3330000",
		"3330000",
		"3330000",
		"3321000",
		"3321000",
	])
	F.foe(s, "boar", "boar", Vector2i(1, 0), Defs.SOUTH)
	F.ally(s, "hero", "hero", Vector2i(5, 0))
	Rules.start_battle(s)
	Rules.end_phase(s)
	var p := EnemyAI.plan(s, s.unit("boar"))
	check(p.has("move_to"), "moves")
	check(s.standing_height(p["move_to"], 2) < 3, "comes down off the plateau (got %s)" % str(p.get("move_to")))


func test_prefers_isolated_target() -> void:
	var s := F.flat(10, 6)
	F.ally(s, "hero", "hero", Vector2i(1, 1))
	F.ally(s, "heracles", "her", Vector2i(1, 2))
	F.ally(s, "atalanta", "ata", Vector2i(7, 1))
	F.foe(s, "bandit", "b", Vector2i(4, 1))
	Rules.start_battle(s)
	Rules.end_phase(s)
	eq(EnemyAI.plan(s, s.unit("b"))["action"]["target"], Vector2i(7, 1), "goes for the lone archer")


func test_valley_battle_reaches_an_outcome() -> void:
	var s := Battles.build("1-4")
	Rules.start_battle(s)
	var rounds := 0
	var falls := 0
	while rounds < 40 and not s.living(Defs.Team.PLAYER).is_empty() and not s.living(Defs.Team.ENEMY).is_empty() \
			and s.unit("hero").alive:
		for team in [Defs.Team.PLAYER, Defs.Team.ENEMY]:
			for u in s.living(team):
				var guard := 0
				while u.alive and not u.has_acted and guard < 4:
					guard += 1
					var p := EnemyAI.plan(s, u)
					if p.has("move_to"):
						Rules.perform(s, {"type": "move", "unit": u.id, "to": p["move_to"]})
					var o := Rules.perform(s, p["action"])
					if not o["ok"]:
						o = Rules.perform(s, {"type": "wait", "unit": u.id})
					for e in o["events"]:
						if e["type"] == "fall":
							falls += 1
					if not Rules.finish_activation(s, u):
						break
			Rules.end_phase(s)
		rounds += 1
	check(rounds < 40, "ends within 40 rounds (took %d)" % rounds)
	print("    1-4 autoplay: %d rounds, players %d, enemies %d, falls %d" % [rounds,
		s.living(Defs.Team.PLAYER).size(), s.living(Defs.Team.ENEMY).size(), falls])
