extends "res://tests/support/test_case.gd"
## Grapple and escape rules (docs/07 §7.1).

const F := preload("res://tests/support/fixtures.gd")


func _grapple(s: BattleState, unit_id: String, cell: Vector2i) -> Dictionary:
	return Rules.perform(s, {"type": "grapple", "unit": unit_id, "target": cell})


func test_escape_values_from_docs() -> void:
	var hero := F.make("hero", "h", Defs.Team.PLAYER, Vector2i.ZERO)
	var heracles := F.make("heracles", "x", Defs.Team.PLAYER, Vector2i.ZERO)
	var lion := F.make("lion", "l", Defs.Team.ENEMY, Vector2i.ZERO)
	var wolf := F.make("wolf", "w", Defs.Team.ENEMY, Vector2i.ZERO)
	eq(Effects.escape_value(hero, lion), 1, "hero vs lion")
	eq(Effects.escape_value(heracles, lion), 3, "heracles vs lion")
	eq(Effects.escape_value(hero, wolf), 3, "hero vs wolf")


func test_hero_holds_lion_for_one_settlement() -> void:
	var s := F.flat()
	F.ally(s, "hero", "hero", Vector2i(1, 2))
	F.foe(s, "lion", "lion", Vector2i(2, 2), Defs.SOUTH)
	Rules.start_battle(s)
	var o := _grapple(s, "hero", Vector2i(2, 2))
	check(o["ok"], o["error"])
	var lion := s.unit("lion")
	eq(lion.escape, 1, "escape")
	eq(lion.facing, Defs.WEST, "facing locked toward grappler")
	Rules.end_phase(s)  # to enemy phase; lion chooses not to struggle
	var ev := Rules.end_phase(s)  # settlement
	eq(sum_events(ev, "damage", "amount", "choke"), 4, "choke is true damage through immunity")
	eq(lion.hp, 56, "lion hp")
	eq(lion.stagger, 15, "grapple tick stagger")
	eq(lion.grappled_by_id, "", "escaped after countdown")
	eq(s.unit("hero").grappling_id, "", "grappler released")


func test_struggle_spends_an_action_and_escapes() -> void:
	var s := F.flat()
	F.ally(s, "hero", "hero", Vector2i(1, 2))
	F.foe(s, "lion", "lion", Vector2i(2, 2))
	Rules.start_battle(s)
	_grapple(s, "hero", Vector2i(2, 2))
	Rules.end_phase(s)
	var o := Rules.perform(s, {"type": "struggle", "unit": "lion"})
	check(o["ok"], o["error"])
	eq(s.unit("lion").grappled_by_id, "", "free")
	check(Rules.finish_activation(s, s.unit("lion")), "lion still has its second action")
	var ev := Rules.end_phase(s)
	eq(sum_events(ev, "damage", "amount", "choke"), 0, "no choke after escape")


func test_grappled_unit_only_hits_grappler_at_70_percent() -> void:
	var s := F.flat()
	F.ally(s, "hero", "hero", Vector2i(2, 2))
	F.ally(s, "atalanta", "ata", Vector2i(3, 3))
	F.foe(s, "wolf", "wolf", Vector2i(3, 2))
	Rules.start_battle(s)
	_grapple(s, "hero", Vector2i(3, 2))
	Rules.end_phase(s)
	eq(Rules.preview(s, F.skill("wolf", "bite", Vector2i(3, 3)))["error"],
		"grappled: can only strike the grappler", "other target")
	var o := Rules.perform(s, F.skill("wolf", "bite", Vector2i(2, 2)))
	check(o["ok"], o["error"])
	eq(sum_events(o["events"], "damage", "amount", "bite"), 2, "(9-6) x0.7")
	eq(Rules.preview(s, {"type": "move", "unit": "wolf", "to": Vector2i(4, 2)})["error"],
		"grappled", "cannot move")


func test_reinforce_raises_escape_up_to_cap() -> void:
	var s := F.flat()
	F.ally(s, "heracles", "her", Vector2i(1, 2))
	F.foe(s, "lion", "lion", Vector2i(2, 2))
	Rules.start_battle(s)
	_grapple(s, "her", Vector2i(2, 2))
	eq(s.unit("lion").escape, 3, "start at boss cap")
	Rules.end_phase(s)
	Rules.end_phase(s)  # settle: 3 -> 2
	eq(s.unit("lion").escape, 2, "after one settlement")
	check(Rules.perform(s, {"type": "reinforce", "unit": "her"})["ok"], "reinforce")
	eq(s.unit("lion").escape, 3, "back to cap")


func test_knockback_breaks_grapple() -> void:
	var s := F.flat()
	F.ally(s, "heracles", "her", Vector2i(3, 1))
	F.ally(s, "hero", "hero", Vector2i(2, 2))
	F.foe(s, "wolf", "wolf", Vector2i(3, 2), Defs.WEST)
	Rules.start_battle(s)
	_grapple(s, "her", Vector2i(3, 2))
	var o := Rules.perform(s, F.skill("hero", "shield_bash", Vector2i(3, 2)))
	check(o["ok"], o["error"])
	eq(s.unit("wolf").pos, Vector2i(4, 2), "pushed east")
	eq(s.unit("her").grappling_id, "", "grapple ended")
	check(has_event(o["events"], "grapple_end"), "grapple_end event")
