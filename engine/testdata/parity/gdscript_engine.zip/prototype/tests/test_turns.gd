extends "res://tests/support/test_case.gd"
## Turn flow, movement, cooldowns, stagger break, preview purity.

const F := preload("res://tests/support/fixtures.gd")


func test_move_then_undo_restores() -> void:
	var s := F.flat()
	F.ally(s, "hero", "hero", Vector2i(1, 1), Defs.SOUTH)
	Rules.start_battle(s)
	check(Rules.perform(s, {"type": "move", "unit": "hero", "to": Vector2i(3, 2)})["ok"], "move")
	eq(s.unit("hero").pos, Vector2i(3, 2), "moved")
	check(Rules.perform(s, {"type": "undo_move", "unit": "hero"})["ok"], "undo")
	eq(s.unit("hero").pos, Vector2i(1, 1), "restored pos")
	eq(s.unit("hero").facing, Defs.SOUTH, "restored facing")


func test_cannot_undo_after_acting_or_act_twice() -> void:
	var s := F.flat()
	F.ally(s, "hero", "hero", Vector2i(1, 1))
	F.foe(s, "wolf", "wolf", Vector2i(3, 2))
	Rules.start_battle(s)
	Rules.perform(s, {"type": "move", "unit": "hero", "to": Vector2i(2, 2)})
	check(Rules.perform(s, F.skill("hero", "spear", Vector2i(3, 2)))["ok"], "attack")
	eq(Rules.perform(s, {"type": "undo_move", "unit": "hero"})["error"], "nothing to undo", "undo")
	eq(Rules.perform(s, F.skill("hero", "spear", Vector2i(3, 2)))["error"], "already acted", "twice")


func test_preview_does_not_mutate() -> void:
	var s := F.flat()
	F.ally(s, "hero", "hero", Vector2i(2, 2))
	F.foe(s, "wolf", "wolf", Vector2i(3, 2))
	Rules.start_battle(s)
	var p := Rules.preview(s, F.skill("hero", "spear", Vector2i(3, 2)))
	eq(s.unit("wolf").hp, 16, "untouched")
	check(not s.unit("hero").has_acted, "hero not spent")
	var o := Rules.perform(s, F.skill("hero", "spear", Vector2i(3, 2)))
	eq(sum_events(o["events"], "damage", "amount"), sum_events(p["events"], "damage", "amount"),
		"preview == perform")


func test_climb_and_drop_limits() -> void:
	var s := F.state(["02300", "00000", "00000"])
	var hero := F.ally(s, "hero", "hero", Vector2i(0, 0))
	Rules.start_battle(s)
	var reach := Movement.destinations(s, hero)
	check(reach.has(Vector2i(1, 0)), "climb 2 with jump 2")
	eq(int(reach[Vector2i(1, 0)]["cost"]), 3, "1 + 2 levels")
	check(not reach.has(Vector2i(2, 0)), "height 3 needs 5 move (3 + 1 + 1)")
	var high := F.state(["30"])
	var h2 := F.ally(high, "hero", "h2", Vector2i(0, 0))
	check(not Movement.destinations(high, h2).has(Vector2i(1, 0)), "drop of 3 blocked")


func test_forest_cost_and_atalanta_stride() -> void:
	var s := F.state(["0000"], [".ff."])
	var hero := F.ally(s, "hero", "hero", Vector2i(0, 0))
	var ata := F.ally(s, "atalanta", "ata", Vector2i(0, 0))
	eq(int(Movement.destinations(s, hero)[Vector2i(2, 0)]["cost"]), 4, "hero 2+2")
	eq(int(Movement.destinations(s, ata)[Vector2i(2, 0)]["cost"]), 2, "atalanta 1+1")


func test_enemies_block_allies_pass_through() -> void:
	var s := F.state(["00000"])
	var hero := F.ally(s, "hero", "hero", Vector2i(0, 0))
	F.ally(s, "atalanta", "ata", Vector2i(1, 0))
	var reach := Movement.destinations(s, hero)
	check(reach.has(Vector2i(2, 0)), "through ally")
	check(not reach.has(Vector2i(1, 0)), "cannot stop on ally")
	F.foe(s, "wolf", "wolf", Vector2i(3, 0))
	check(not Movement.destinations(s, hero).has(Vector2i(4, 0)), "enemy blocks")


func test_cooldown_counts_down_at_round_end() -> void:
	var s := F.flat()
	F.ally(s, "hero", "hero", Vector2i(2, 2))
	F.foe(s, "bandit", "b", Vector2i(3, 2))
	Rules.start_battle(s)
	Rules.perform(s, F.skill("hero", "shield_bash", Vector2i(3, 2)))
	eq(s.unit("hero").cooldown("shield_bash"), 2, "set")
	Rules.end_phase(s)
	Rules.end_phase(s)
	eq(s.unit("hero").cooldown("shield_bash"), 1, "after round 1")
	eq(Rules.preview(s, F.skill("hero", "shield_bash", Vector2i(4, 2)))["error"], "on cooldown", "still")


func test_boss_has_two_activations() -> void:
	var s := F.flat()
	F.foe(s, "lion", "lion", Vector2i(2, 2))
	Rules.start_battle(s)
	Rules.end_phase(s)
	var lion := s.unit("lion")
	check(Rules.perform(s, {"type": "wait", "unit": "lion"})["ok"], "first")
	check(Rules.finish_activation(s, lion), "has a second")
	check(Rules.perform(s, {"type": "move", "unit": "lion", "to": Vector2i(3, 2)})["ok"], "second move")
	check(not Rules.finish_activation(s, lion), "spent")


func test_stagger_break_stuns_and_strips_immunity() -> void:
	var s := F.flat()
	F.ally(s, "hero", "hero", Vector2i(1, 2))
	var lion := F.foe(s, "lion", "lion", Vector2i(2, 2), Defs.EAST)
	Rules.start_battle(s)
	lion.stagger = 85
	var o := Rules.perform(s, F.skill("hero", "spear", Vector2i(2, 2)))  # back hit +20
	check(has_event(o["events"], "broken"), "broken")
	check(lion.has_status("staggered") and lion.has_status("stunned"), "statuses")
	var ev := Rules.end_phase(s)
	check(has_event(ev, "stun_skip"), "lion skips enemy phase")
	check(lion.has_acted, "spent")
	Rules.end_phase(s)  # round 1 settles; round 2 player phase
	check(lion.has_status("staggered"), "still broken during round 2 player phase")
	var hit := Damage.compute(s, s.unit("hero"), lion, 1.0, Defs.DamageType.PHYSICAL, false)
	eq(hit["amount"], 15, "(12-4) x1.5 back x1.25 broken")
	Rules.end_phase(s)
	Rules.end_phase(s)
	check(not lion.has_status("staggered"), "window closed after round 2")


func test_boss_resists_control_unless_broken() -> void:
	var s := F.flat()
	var lion := F.foe(s, "lion", "lion", Vector2i(2, 2))
	var ev: Array = []
	check(not Effects.add_status(s, lion, "rooted", 1, ev), "super armor")
	lion.statuses["staggered"] = 1
	check(Effects.add_status(s, lion, "rooted", 1, ev), "broken boss can be rooted")


func test_path_through_ally_reconstructs() -> void:
	var s := F.state(["00000"])
	F.ally(s, "hero", "hero", Vector2i(0, 0))
	F.ally(s, "atalanta", "ata", Vector2i(1, 0))
	Rules.start_battle(s)
	var o := Rules.perform(s, {"type": "move", "unit": "hero", "to": Vector2i(2, 0)})
	check(o["ok"], o["error"])
	eq(o["events"][0]["path"], [Vector2i(1, 0), Vector2i(2, 0)] as Array[Vector2i], "path through ally")


func test_rooted_unit_can_only_stay() -> void:
	var s := F.flat()
	var hero := F.ally(s, "hero", "hero", Vector2i(2, 2))
	hero.statuses["rooted"] = 1
	eq(Movement.destinations(s, hero).keys(), [Vector2i(2, 2)], "only its own cell")


func test_state_copy_is_independent() -> void:
	var s := F.flat()
	var hero := F.ally(s, "hero", "hero", Vector2i(1, 1))
	hero.statuses["guard"] = 1
	hero.cooldowns["shield_bash"] = 2
	var c := s.copy()
	var ch := c.unit("hero")
	ch.hp -= 5
	ch.pos = Vector2i(3, 3)
	ch.statuses["burning"] = 2
	ch.cooldowns["shield_bash"] = 0
	ch.skills.append("x")
	eq(hero.hp, 40, "hp")
	eq(hero.pos, Vector2i(1, 1), "pos")
	check(not hero.has_status("burning"), "statuses")
	eq(hero.cooldown("shield_bash"), 2, "cooldowns")
	check(not hero.skills.has("x"), "skills")
	# every script variable must be copied: guard against new fields being forgotten in copy()
	for prop in hero.get_property_list():
		if prop["usage"] & PROPERTY_USAGE_SCRIPT_VARIABLE:
			eq(s.copy().unit("hero").get(prop["name"]), hero.get(prop["name"]), "field " + prop["name"])
