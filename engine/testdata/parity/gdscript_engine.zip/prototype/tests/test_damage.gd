extends "res://tests/support/test_case.gd"
## Damage formula cases from docs/07 §4 and docs/09 §4.

const F := preload("res://tests/support/fixtures.gd")


func _hit(outcome: Dictionary, source: String) -> int:
	return sum_events(outcome["events"], "damage", "amount", source)


func test_spear_vs_wolf_front_is_11() -> void:
	var s := F.flat()
	F.ally(s, "hero", "hero", Vector2i(2, 2))
	F.foe(s, "wolf", "wolf", Vector2i(3, 2))
	Rules.start_battle(s)
	var o := Rules.perform(s, F.skill("hero", "spear", Vector2i(3, 2)))
	check(o["ok"], o["error"])
	eq(_hit(o, "spear"), 11, "12 str - 1 def")


func test_spear_vs_bandit_front_9_back_13() -> void:
	var s := F.flat()
	F.ally(s, "hero", "hero", Vector2i(2, 2))
	F.foe(s, "bandit", "front", Vector2i(3, 2), Defs.WEST)
	F.foe(s, "bandit", "back", Vector2i(2, 3), Defs.SOUTH)
	Rules.start_battle(s)
	eq(_hit(Rules.preview(s, F.skill("hero", "spear", Vector2i(3, 2))), "spear"), 9, "front")
	eq(_hit(Rules.preview(s, F.skill("hero", "spear", Vector2i(2, 3))), "spear"), 13, "back 9 x1.5")


func test_spear_reaches_two_tiles_in_a_line_only() -> void:
	var s := F.flat()
	F.ally(s, "hero", "hero", Vector2i(2, 2))
	F.foe(s, "wolf", "line", Vector2i(4, 2))
	F.foe(s, "wolf", "diag", Vector2i(3, 3))
	Rules.start_battle(s)
	check(Rules.preview(s, F.skill("hero", "spear", Vector2i(4, 2)))["ok"], "two tiles in line")
	eq(Rules.preview(s, F.skill("hero", "spear", Vector2i(3, 3)))["error"], "not in line", "diagonal")


func test_high_ground_bonus() -> void:
	var s := F.state(["0000", "0100", "0000"])
	F.ally(s, "hero", "hero", Vector2i(1, 1))
	F.foe(s, "wolf", "wolf", Vector2i(2, 1))
	Rules.start_battle(s)
	eq(_hit(Rules.preview(s, F.skill("hero", "spear", Vector2i(2, 1))), "spear"), 13, "11 x1.2")


func test_chief_blocks_front_not_back() -> void:
	var s := F.flat()
	F.ally(s, "hero", "hero", Vector2i(2, 2))
	F.foe(s, "bandit_chief", "chief", Vector2i(3, 2), Defs.WEST)
	Rules.start_battle(s)
	eq(_hit(Rules.preview(s, F.skill("hero", "spear", Vector2i(3, 2))), "spear"), 4, "8 x0.5")
	s.unit("chief").facing = Defs.EAST
	eq(_hit(Rules.preview(s, F.skill("hero", "spear", Vector2i(3, 2))), "spear"), 12, "8 x1.5")


func test_lion_immune_but_back_hit_builds_stagger() -> void:
	var s := F.flat()
	F.ally(s, "hero", "hero", Vector2i(1, 2))
	F.foe(s, "lion", "lion", Vector2i(2, 2), Defs.EAST)
	Rules.start_battle(s)
	var o := Rules.perform(s, F.skill("hero", "spear", Vector2i(2, 2)))
	eq(_hit(o, "spear"), 0, "physical immune")
	eq(s.unit("lion").hp, 60, "lion hp unchanged")
	eq(s.unit("lion").stagger, 20, "back hit stagger")


func test_broken_lion_takes_boosted_physical_damage() -> void:
	var s := F.flat()
	F.ally(s, "hero", "hero", Vector2i(1, 2))
	var lion := F.foe(s, "lion", "lion", Vector2i(2, 2), Defs.WEST)
	Rules.start_battle(s)
	lion.statuses["staggered"] = 2
	eq(_hit(Rules.preview(s, F.skill("hero", "spear", Vector2i(2, 2))), "spear"), 10, "(12-4) x1.25")


func test_forest_cover_reduces_ranged() -> void:
	var s := F.state(["000000", "000000", "000000"], ["......", "...f..", "......"])
	F.ally(s, "atalanta", "ata", Vector2i(0, 1))
	F.foe(s, "bandit", "bandit", Vector2i(3, 1))
	Rules.start_battle(s)
	eq(_hit(Rules.preview(s, F.skill("ata", "shoot", Vector2i(3, 1))), "shoot"), 6, "8 x0.75")


func test_mark_boosts_damage() -> void:
	var s := F.flat()
	F.ally(s, "atalanta", "ata", Vector2i(0, 2))
	F.foe(s, "wolf", "wolf", Vector2i(3, 2))
	Rules.start_battle(s)
	check(Rules.perform(s, {"type": "mark", "unit": "ata", "target": Vector2i(3, 2)})["ok"], "mark")
	eq(_hit(Rules.preview(s, F.skill("ata", "shoot", Vector2i(3, 2))), "shoot"), 11, "10 x1.15")
	eq(Rules.perform(s, {"type": "mark", "unit": "ata", "target": Vector2i(3, 2)})["error"],
		"cannot mark", "once per round")


func test_atalanta_cannot_shoot_adjacent() -> void:
	var s := F.flat()
	F.ally(s, "atalanta", "ata", Vector2i(2, 2))
	F.foe(s, "wolf", "wolf", Vector2i(3, 2))
	Rules.start_battle(s)
	eq(Rules.preview(s, F.skill("ata", "shoot", Vector2i(3, 2)))["error"], "out of range", "adjacent")


func test_flank_and_assist() -> void:
	var s := F.flat()
	F.ally(s, "hero", "hero", Vector2i(2, 2))
	F.ally(s, "heracles", "her", Vector2i(4, 2), Defs.WEST)
	F.foe(s, "wolf", "wolf", Vector2i(3, 2), Defs.WEST)
	Rules.start_battle(s)
	var o := Rules.perform(s, F.skill("hero", "spear", Vector2i(3, 2)))
	eq(_hit(o, "spear"), 12, "front 11 x1.1 flank")
	# Heracles assists from behind: floor(20*0.3)=6 - 1 = 5, x1.5 back x1.1 flank = 8.
	eq(_hit(o, "assist"), 8, "assist")
	check(s.unit("her").assist_used, "assist consumed")


func test_low_bump_does_not_block_line_of_sight() -> void:
	var s := F.state(["010000", "000000"])
	F.ally(s, "atalanta", "ata", Vector2i(0, 0))
	F.foe(s, "wolf", "wolf", Vector2i(3, 0))
	Rules.start_battle(s)
	check(Rules.preview(s, F.skill("ata", "shoot", Vector2i(3, 0)))["ok"], "one-level bump")
	s.grid.set_height(Vector2i(1, 0), 2)
	eq(Rules.preview(s, F.skill("ata", "shoot", Vector2i(3, 0)))["error"], "no line of sight", "two-level wall")
