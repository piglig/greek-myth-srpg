extends "res://tests/support/test_case.gd"
## Knockback, falls, collisions and edges (docs/07 §5.1).

const F := preload("res://tests/support/fixtures.gd")


func test_boar_pushed_off_three_level_cliff_takes_9() -> void:
	# Boar (2x2) stands on a height-3 plateau; columns 3+ are the valley floor.
	var s := F.state(["333000", "333000", "000000"])
	F.ally(s, "heracles", "her", Vector2i(0, 0))
	F.foe(s, "boar", "boar", Vector2i(1, 0), Defs.EAST)
	Rules.start_battle(s)
	var o := Rules.perform(s, F.skill("her", "club", Vector2i(1, 0)))
	check(o["ok"], o["error"])
	eq(s.unit("boar").pos, Vector2i(3, 0), "pushed 2 tiles")
	eq(sum_events(o["events"], "damage", "amount", "fall"), 9, "3 levels x3")


func test_edge_kills_normal_enemy() -> void:
	var s := F.flat(4, 4)
	F.ally(s, "hero", "hero", Vector2i(2, 1))
	F.foe(s, "wolf", "wolf", Vector2i(3, 1))
	Rules.start_battle(s)
	var o := Rules.perform(s, F.skill("hero", "shield_bash", Vector2i(3, 1)))
	check(has_event(o["events"], "edge"), "edge event")
	check(not s.unit("wolf").alive, "wolf gone")


func test_edge_hurts_players_instead_of_killing() -> void:
	var s := F.flat(4, 4)
	F.foe(s, "bandit", "b", Vector2i(1, 1))
	F.add(s, "hero", "hero", Defs.Team.PLAYER, Vector2i(0, 1))
	s.unit("b").skills.append("gore")
	Rules.start_battle(s)
	Rules.end_phase(s)
	var o := Rules.perform(s, F.skill("b", "gore", Vector2i(0, 1)))
	check(o["ok"], o["error"])
	check(s.unit("hero").alive, "hero survives")
	eq(sum_events(o["events"], "damage", "amount", "edge"), 10, "edge damage")


func test_collision_hurts_both() -> void:
	var s := F.flat()
	F.ally(s, "hero", "hero", Vector2i(1, 1))
	F.foe(s, "wolf", "a", Vector2i(2, 1))
	F.foe(s, "wolf", "b", Vector2i(3, 1))
	Rules.start_battle(s)
	var o := Rules.perform(s, F.skill("hero", "shield_bash", Vector2i(2, 1)))
	eq(sum_events(o["events"], "damage", "amount", "collision"), 6, "3 each")
	eq(s.unit("a").pos, Vector2i(2, 1), "did not move")


func test_wall_stops_knockback() -> void:
	var s := F.state(["0020"])
	F.ally(s, "hero", "hero", Vector2i(0, 0))
	F.foe(s, "wolf", "wolf", Vector2i(1, 0))
	Rules.start_battle(s)
	var o := Rules.perform(s, F.skill("hero", "shield_bash", Vector2i(1, 0)))
	eq(s.unit("wolf").pos, Vector2i(1, 0), "blocked by higher cell")
	eq(sum_events(o["events"], "damage", "amount", "collision"), 3, "wall bump")


func test_boss_knockback_and_fall_build_stagger() -> void:
	var s := F.state(["33300", "33300", "00000"])
	F.ally(s, "heracles", "her", Vector2i(0, 0))
	F.foe(s, "lion", "lion", Vector2i(1, 0), Defs.WEST)
	Rules.start_battle(s)
	Rules.perform(s, F.skill("her", "club", Vector2i(1, 0)))
	# front hit: 0 stagger; knockback +15; fall 3 levels +15.
	eq(s.unit("lion").stagger, 30, "knockback + fall stagger")
	eq(s.unit("lion").hp, 51, "fall damage is true damage")
