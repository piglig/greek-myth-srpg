extends "res://tests/support/test_case.gd"
## Simulation harness: reproducibility and record integrity (docs/11).


func _strip(rec: Dictionary) -> Dictionary:
	var r := rec.duplicate(true)
	r.erase("ms")
	return r


func test_same_seed_same_battle() -> void:
	var prof := PlayerBot.profile("novice")
	var a := BattleRunner.run("test", {}, prof, 42)
	var b := BattleRunner.run("test", {}, prof, 42)
	eq(_strip(a), _strip(b), "identical records for the same seed")


func test_different_seeds_can_differ() -> void:
	var prof := PlayerBot.profile("novice")
	var seen := {}
	for seed in 6:
		var r := BattleRunner.run("test", {}, prof, seed)
		seen[JSON.stringify(_strip(r)["units"])] = true
	check(seen.size() > 1, "novice noise produces different battles")


func test_record_accounts_for_all_enemy_damage() -> void:
	var r := BattleRunner.run("test", {}, PlayerBot.profile("novice"), 7)
	var by_source := 0
	for k in r["dmg_to_enemy"]:
		by_source += int(r["dmg_to_enemy"][k])
	var taken := 0
	for id in r["units"]:
		if r["units"][id]["team"] == "enemy":
			taken += int(r["units"][id]["taken"])
	eq(by_source, taken, "damage by source equals damage taken by enemies")
	check(r["result"] in ["win", "loss_hero", "loss_wipe", "timeout"], "valid result")
