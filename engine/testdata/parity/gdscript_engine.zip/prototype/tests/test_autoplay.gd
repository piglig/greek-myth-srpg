extends "res://tests/support/test_case.gd"
## Smoke test: both sides driven by the placeholder AI play the M2 test battle to the end.


func _run_side(s: BattleState, team: int) -> void:
	for u in s.living(team):
		var guard := 0
		while u.alive and not u.has_acted and guard < 4:
			guard += 1
			var p := EnemyAI.plan(s, u)
			if p.has("move_to"):
				var mv := Rules.perform(s, {"type": "move", "unit": u.id, "to": p["move_to"]})
				check(mv["ok"], "%s move: %s" % [u.id, mv["error"]])
			var o := Rules.perform(s, p["action"])
			if not o["ok"]:
				o = Rules.perform(s, {"type": "wait", "unit": u.id})
			if not Rules.finish_activation(s, u):
				break


func test_test_battle_reaches_an_outcome() -> void:
	var s := Battles.build("test")
	Rules.start_battle(s)
	var rounds := 0
	while rounds < 30 and not s.living(Defs.Team.PLAYER).is_empty() and not s.living(Defs.Team.ENEMY).is_empty():
		_run_side(s, Defs.Team.PLAYER)
		Rules.end_phase(s)
		_run_side(s, Defs.Team.ENEMY)
		Rules.end_phase(s)
		rounds += 1
	check(rounds < 30, "battle ends within 30 rounds (took %d)" % rounds)
	check(s.living(Defs.Team.PLAYER).is_empty() or s.living(Defs.Team.ENEMY).is_empty(), "one side wiped")
	print("    autoplay: %d rounds, players left %d, enemies left %d" % [rounds,
		s.living(Defs.Team.PLAYER).size(), s.living(Defs.Team.ENEMY).size()])
