extends "res://tests/support/test_case.gd"
## First two nodes of each branch (docs/08) and the pre-battle skill budget.

const F := preload("res://tests/support/fixtures.gd")


func _hero(s: BattleState, pos: Vector2i, picks: Array, facing: Vector2i = Defs.EAST) -> UnitState:
	var u := F.ally(s, "hero", "hero", pos, facing)
	SkillTree.apply(u, picks)
	return u


func _ata(s: BattleState, pos: Vector2i, picks: Array) -> UnitState:
	var u := F.ally(s, "atalanta", "ata", pos)
	SkillTree.apply(u, picks)
	return u


func test_budget_and_prerequisites() -> void:
	eq(SkillTree.validate("hero", ["slam", "iron_arm", "shield_wall"]), "", "4 points ok")
	eq(SkillTree.validate("hero", ["slam", "iron_arm", "shield_wall", "intercept"]), "over budget", "6 points")
	eq(SkillTree.validate("hero", ["iron_arm"]), "missing prerequisite", "node 2 needs node 1")
	eq(SkillTree.validate("atalanta", SkillTree.default_picks()["atalanta"]), "", "default atalanta")
	eq(SkillTree.all_builds("hero").size(), 8, "hero builds within 4 points")


func test_shield_wall_protects_guarded_neighbours() -> void:
	var s := F.flat()
	_hero(s, Vector2i(2, 2), ["shield_wall"])
	F.ally(s, "atalanta", "ata", Vector2i(3, 2))
	F.foe(s, "wolf", "wolf", Vector2i(4, 2))
	Rules.start_battle(s)
	Rules.perform(s, {"type": "wait", "unit": "hero"})
	Rules.end_phase(s)
	var o := Rules.perform(s, F.skill("wolf", "bite", Vector2i(3, 2)))
	# wolf 9 - atalanta def 3 = 6, x0.85 = 5.1 -> 5
	eq(sum_events(o["events"], "damage", "amount", "bite"), 5, "shield wall")


func test_intercept_redirects_once_per_round() -> void:
	var s := F.flat()
	_hero(s, Vector2i(2, 2), ["shield_wall", "intercept"])
	F.ally(s, "atalanta", "ata", Vector2i(3, 2))
	F.foe(s, "wolf", "w1", Vector2i(4, 2))
	F.foe(s, "wolf", "w2", Vector2i(3, 3), Defs.NORTH)
	Rules.start_battle(s)
	Rules.end_phase(s)
	var o := Rules.perform(s, F.skill("w1", "bite", Vector2i(3, 2)))
	check(has_event(o["events"], "intercept"), "intercepted")
	eq(s.unit("ata").hp, 30, "atalanta untouched")
	check(s.unit("hero").hp < 40, "hero took it")
	var o2 := Rules.perform(s, F.skill("w2", "bite", Vector2i(3, 2)))
	check(not has_event(o2["events"], "intercept"), "only once per round")
	check(s.unit("ata").hp < 30, "second bite lands")


func test_iron_arm_choke_and_damage_reduction() -> void:
	var s := F.flat()
	_hero(s, Vector2i(2, 2), ["slam", "iron_arm"])
	F.foe(s, "bandit", "b", Vector2i(3, 2))
	Rules.start_battle(s)
	Rules.perform(s, {"type": "grapple", "unit": "hero", "target": Vector2i(3, 2)})
	Rules.end_phase(s)
	var o := Rules.perform(s, F.skill("b", "slash", Vector2i(2, 2)))
	# (10 - 6) = 4 x0.7 grappled x0.8 iron arm = 2.24 -> 2
	eq(sum_events(o["events"], "damage", "amount", "slash"), 2, "reduced")
	var ev := Rules.end_phase(s)
	eq(sum_events(ev, "damage", "amount", "choke"), 7, "4 + 3 choke")


func test_slam_throws_off_a_ledge() -> void:
	var s := F.state(["2200", "2200"])
	_hero(s, Vector2i(0, 0), ["slam"])
	F.foe(s, "wolf", "wolf", Vector2i(1, 0))
	Rules.start_battle(s)
	Rules.perform(s, {"type": "grapple", "unit": "hero", "target": Vector2i(1, 0)})
	Rules.end_phase(s)
	Rules.end_phase(s)
	var o := Rules.perform(s, {"type": "slam", "unit": "hero", "target": Vector2i(2, 0)})
	check(o["ok"], o["error"])
	eq(s.unit("wolf").pos, Vector2i(2, 0), "thrown east")
	eq(sum_events(o["events"], "damage", "amount", "fall"), 6, "2 levels")
	eq(s.unit("hero").grappling_id, "", "grapple over")
	s.unit("hero").has_acted = false
	eq(Rules.preview(s, {"type": "slam", "unit": "hero", "target": Vector2i(3, 0)})["error"],
		"cannot slam", "needs a hold")


func test_patience_rewards_standing_still() -> void:
	var s := F.flat()
	_ata(s, Vector2i(0, 2), ["vital_shot", "patience"])
	F.foe(s, "wolf", "wolf", Vector2i(3, 2))
	Rules.start_battle(s)
	# (11 - 1) x1.25 = 12
	eq(sum_events(Rules.preview(s, F.skill("ata", "shoot", Vector2i(3, 2)))["events"], "damage", "amount", "shoot"),
		12, "still")
	Rules.perform(s, {"type": "move", "unit": "ata", "to": Vector2i(0, 3)})
	eq(sum_events(Rules.preview(s, F.skill("ata", "shoot", Vector2i(3, 2)))["events"], "damage", "amount", "shoot"),
		10, "moved")


func test_vital_shot_flank_on_marked_boss_adds_stagger() -> void:
	var s := F.flat(10, 6)
	_ata(s, Vector2i(0, 2), ["vital_shot"])
	F.foe(s, "lion", "lion", Vector2i(4, 2), Defs.EAST)
	Rules.start_battle(s)
	Rules.perform(s, {"type": "mark", "unit": "ata", "target": Vector2i(4, 2)})
	Rules.perform(s, F.skill("ata", "vital_shot", Vector2i(4, 2)))
	eq(s.unit("lion").stagger, 35, "back 20 + marked flank 15")


func test_skirmish_moves_after_attacking() -> void:
	var s := F.flat()
	_ata(s, Vector2i(0, 2), ["skirmish"])
	F.foe(s, "wolf", "wolf", Vector2i(3, 2))
	Rules.start_battle(s)
	Rules.perform(s, F.skill("ata", "shoot", Vector2i(3, 2)))
	eq(s.unit("ata").post_move, 2, "bonus granted")
	eq(Rules.preview(s, {"type": "move", "unit": "ata", "to": Vector2i(0, 5)})["error"], "unreachable", "3 is too far")
	check(Rules.perform(s, {"type": "move", "unit": "ata", "to": Vector2i(0, 4)})["ok"], "2 tiles")
	eq(Rules.preview(s, {"type": "move", "unit": "ata", "to": Vector2i(0, 3)})["error"], "cannot move now", "spent")


func test_leap_shot_lands_high_then_shoots() -> void:
	var s := F.state(["0300000", "0000000"])
	_ata(s, Vector2i(0, 0), ["skirmish", "leap_shot"])
	F.foe(s, "wolf", "wolf", Vector2i(5, 0))
	Rules.start_battle(s)
	var act := {"type": "skill", "unit": "ata", "skill": "leap_shot", "target": Vector2i(5, 0)}
	eq(Rules.preview(s, act)["error"], "need landing", "landing required")
	act["to"] = Vector2i(1, 0)
	var o := Rules.perform(s, act)
	check(o["ok"], o["error"])
	eq(s.unit("ata").pos, Vector2i(1, 0), "on the pillar")
	# floor(11 x0.8) = 8 - 1 = 7, x1.2 high ground = 8
	eq(sum_events(o["events"], "damage", "amount", "leap_shot"), 8, "shot from height")
	var s2 := F.state(["0400000"])
	_ata(s2, Vector2i(0, 0), ["skirmish", "leap_shot"])
	F.foe(s2, "wolf", "wolf", Vector2i(5, 0))
	Rules.start_battle(s2)
	act["to"] = Vector2i(1, 0)
	eq(Rules.preview(s2, act)["error"], "bad landing", "4 levels is too high")
