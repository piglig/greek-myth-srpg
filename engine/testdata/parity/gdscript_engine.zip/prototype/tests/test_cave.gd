extends "res://tests/support/test_case.gd"
## Boss lair rules (docs/09 1-5): pounce, roar, boulders, retreating into the cave and bursting out.

const F := preload("res://tests/support/fixtures.gd")


## 12x8 flat field with a cave: entrances west (1,3) and east (9,3), one boulder beside each.
func _lair() -> BattleState:
	var s := F.flat(12, 8)
	s.cave = {"boss": "lion", "trigger_hp": 30, "emerge_actions": 1, "last": "",
		"entrances": {"west": {"anchor": Vector2i(1, 3), "sealed": false}, "east": {"anchor": Vector2i(9, 3), "sealed": false}},
		"boulders": {"bw": {"pos": Vector2i(0, 6), "seals": "west", "progress": 0, "placed": false},
			"be": {"pos": Vector2i(11, 6), "seals": "east", "progress": 0, "placed": false}}}
	return s


func _enemy_turn(s: BattleState) -> Array:
	var events: Array = []
	for e in s.living(Defs.Team.ENEMY):
		var guard := 0
		while e.alive and not e.has_acted and guard < 4:
			guard += 1
			var p := EnemyAI.plan(s, e)
			if p.has("move_to"):
				events.append_array(Rules.perform(s, {"type": "move", "unit": e.id, "to": p["move_to"]})["events"])
			events.append_array(Rules.perform(s, p["action"])["events"])
			if not Rules.finish_activation(s, e):
				break
	return events


func test_pounce_must_land_next_to_its_target() -> void:
	var s := F.flat(12, 8)
	F.ally(s, "hero", "hero", Vector2i(8, 3), Defs.WEST)
	F.foe(s, "lion", "lion", Vector2i(1, 3), Defs.EAST)
	Rules.start_battle(s)
	Rules.end_phase(s)
	eq(Rules.validate(s, {"type": "skill", "unit": "lion", "skill": "pounce", "target": Vector2i(8, 3), "to": Vector2i(5, 3)}),
		"out of range", "landing at columns 5-6 leaves the hero at 8 two tiles away")
	eq(Rules.validate(s, {"type": "skill", "unit": "lion", "skill": "pounce", "target": Vector2i(8, 3), "to": Vector2i(7, 3)}),
		"bad landing", "more than 4 tiles")


func test_pounce_adjacent_target_takes_damage_and_is_pushed() -> void:
	var s := F.flat(12, 8)
	F.ally(s, "hero", "hero", Vector2i(7, 3), Defs.WEST)
	F.foe(s, "lion", "lion", Vector2i(1, 3), Defs.EAST)
	Rules.start_battle(s)
	Rules.end_phase(s)
	var o := Rules.perform(s, {"type": "skill", "unit": "lion", "skill": "pounce", "target": Vector2i(7, 3), "to": Vector2i(5, 3)})
	check(o["ok"], o["error"])
	eq(sum_events(o["events"], "damage", "amount", "pounce"), 6, "floor(16 x 0.8) - 6")
	eq(s.unit("hero").pos, Vector2i(8, 3), "knocked back one tile")
	eq(s.unit("lion").cooldown("pounce"), 2, "cooldown")
	eq(Rules.validate(s, {"type": "skill", "unit": "lion", "skill": "pounce", "target": Vector2i(8, 3), "to": Vector2i(11, 3)}),
		"already acted", "one action per activation")


func test_roar_fears_players_in_two_tiles_only() -> void:
	var s := F.flat(12, 8)
	F.ally(s, "hero", "hero", Vector2i(5, 3))
	F.ally(s, "atalanta", "ata", Vector2i(9, 3))
	F.foe(s, "lion", "lion", Vector2i(2, 3))
	Rules.start_battle(s)
	Rules.end_phase(s)
	var o := Rules.perform(s, {"type": "skill", "unit": "lion", "skill": "roar", "target": Vector2i(2, 3)})
	check(o["ok"], o["error"])
	check(s.unit("hero").has_status("feared"), "hero (2 tiles from the 2x2 lion) is feared")
	check(not s.unit("ata").has_status("feared"), "atalanta is out of range")
	Rules.finish_activation(s, s.unit("lion"))
	Rules.perform(s, {"type": "wait", "unit": "lion"})
	Rules.end_phase(s)
	check(not s.unit("hero").has_status("feared"), "fear lasts one round: gone by the next player phase")
	check(s.unit("hero").has_status("control_immune"), "then immune for a round")


func test_boulder_blocks_and_seals() -> void:
	var s := _lair()
	F.ally(s, "hero", "hero", Vector2i(1, 6))
	F.ally(s, "heracles", "her", Vector2i(10, 6))
	F.foe(s, "lion", "lion", Vector2i(5, 1))
	Rules.start_battle(s)
	check(not Movement.destinations(s, s.unit("hero")).has(Vector2i(0, 6)), "a boulder cannot be walked onto")
	eq(Rules.validate(s, {"type": "push_boulder", "unit": "hero", "target": Vector2i(5, 5)}), "no boulder there", "empty cell")
	var o := Rules.perform(s, {"type": "push_boulder", "unit": "hero", "target": Vector2i(0, 6)})
	check(o["ok"], o["error"])
	check(not s.cave["entrances"]["west"]["sealed"], "an ordinary unit needs two pushes")
	Rules.end_phase(s)
	Rules.perform(s, {"type": "wait", "unit": "lion"})
	Rules.end_phase(s)
	o = Rules.perform(s, {"type": "push_boulder", "unit": "hero", "target": Vector2i(0, 6)})
	check(has_event(o["events"], "sealed"), "second push seals the west entrance")
	eq(s.open_entrances(), ["east"] as Array[String], "one entrance left")
	check(Movement.destinations(s, s.unit("her")).size() > 0, "movement still works")
	eq(Rules.validate(s, {"type": "push_boulder", "unit": "her", "target": Vector2i(11, 6)}),
		"cannot seal the last entrance", "the lair always keeps one way out")


func test_strong_unit_seals_in_one_push() -> void:
	var s := _lair()
	F.ally(s, "hero", "hero", Vector2i(5, 6))
	F.ally(s, "heracles", "her", Vector2i(10, 6))
	F.foe(s, "lion", "lion", Vector2i(5, 1))
	Rules.start_battle(s)
	var o := Rules.perform(s, {"type": "push_boulder", "unit": "her", "target": Vector2i(11, 6)})
	check(has_event(o["events"], "sealed"), "Heracles rolls it home at once")
	check(s.boulder_at(Vector2i(11, 6)) == "", "the boulder left its cell")


func test_wounded_lion_retreats_then_bursts_out_near_the_softest_player() -> void:
	var s := _lair()
	F.ally(s, "hero", "hero", Vector2i(2, 6))
	F.ally(s, "atalanta", "ata", Vector2i(9, 6))
	var lion := F.foe(s, "lion", "lion", Vector2i(5, 0))
	lion.hp = 30
	Rules.start_battle(s)
	Rules.end_phase(s)
	var ev := _enemy_turn(s)
	check(has_event(ev, "retreat"), "at half health it goes to ground")
	check(lion.hidden, "hidden")
	Rules.end_phase(s)
	eq(Rules.validate(s, F.skill("hero", "spear", Vector2i(5, 0))), "no enemy there", "a hidden boss cannot be targeted")
	check(s.unit_at(Vector2i(5, 0)) == null, "and blocks nothing")
	eq(EnemyAI.cave_entrance(s, lion), "east", "intent: the entrance nearest Atalanta (lowest defence)")
	Rules.end_phase(s)
	ev = _enemy_turn(s)
	check(has_event(ev, "emerge"), "bursts out next enemy phase")
	check(not lion.hidden, "visible again")
	for e in ev:
		if e["type"] == "emerge":
			eq(e["to"], Vector2i(9, 3), "at the east entrance")
	check(has_event(ev, "attack") or has_event(ev, "leap"), "and attacks in the same phase")
	Rules.end_phase(s)
	Rules.end_phase(s)
	ev = _enemy_turn(s)
	check(has_event(ev, "retreat"), "having been out for a player phase, it goes back in")


func test_sealed_entrance_forces_the_other_one() -> void:
	var s := _lair()
	F.ally(s, "hero", "hero", Vector2i(2, 6))
	F.ally(s, "atalanta", "ata", Vector2i(9, 6))
	var lion := F.foe(s, "lion", "lion", Vector2i(5, 0))
	s.cave["entrances"]["east"]["sealed"] = true
	lion.hidden = true
	eq(EnemyAI.cave_entrance(s, lion), "west", "only the west entrance is open")


func test_held_lion_cannot_retreat_and_breaks_free_with_one_action() -> void:
	var s := _lair()
	F.ally(s, "heracles", "her", Vector2i(4, 2))
	F.ally(s, "hero", "hero", Vector2i(2, 6))
	var lion := F.foe(s, "lion", "lion", Vector2i(5, 2))
	lion.hp = 20
	Rules.start_battle(s)
	check(Rules.perform(s, {"type": "grapple", "unit": "her", "target": Vector2i(5, 2)})["ok"], "grapple")
	eq(lion.escape, 3, "reference Heracles holds the lion at the boss cap")
	Rules.end_phase(s)
	var ev := _enemy_turn(s)
	check(not has_event(ev, "retreat"), "a held lion cannot slip back into the cave")
	check(has_event(ev, "struggle"), "it struggles instead")
	eq(lion.grappled_by_id, "", "two boss struggles (2 points each) break a hold of 3")
	check(not lion.hidden, "still outside")


func test_boss_fight_reaches_an_outcome() -> void:
	var rec := BattleRunner.run("1-5", SkillTree.default_picks(), PlayerBot.profile("novice"), 3, 30)
	check(rec["result"] != "timeout", "1-5 ends within 30 rounds (%s in %d)" % [rec["result"], rec["rounds"]])
