class_name UnitCatalog
extends RefCounted
## Unit definitions from data/tables/units.json.


static func units() -> Dictionary:
	return Tables.get_table("units")


static func unit_def(def_id: String) -> Dictionary:
	assert(units().has(def_id), "unknown unit %s" % def_id)
	return units()[def_id]


static func make(def_id: String, id: String, team: int, pos: Vector2i,
		facing: Vector2i = Defs.SOUTH) -> UnitState:
	var d := unit_def(def_id)
	var u := UnitState.new()
	u.id = id
	u.def_id = def_id
	u.display_name = d["name"]
	u.team = team
	u.pos = pos
	u.facing = facing
	u.size = int(d.get("size", 1))
	u.max_hp = int(d.get("max_hp", d["hp"]))
	u.hp = int(d["hp"])
	u.strength = int(d["str"])
	u.divinity = int(d.get("div", 0))
	u.defense = int(d["def"])
	u.will = int(d["wil"])
	u.move = int(d["move"])
	u.jump = int(d["jump"])
	for s in d["skills"]:
		u.skills.append(s)
	# JSON numbers arrive as floats; keep integer-valued traits (e.g. choke damage) integral.
	for k in d.get("traits", {}):
		var v = d["traits"][k]
		u.traits[k] = int(v) if v is float else v
	u.actions_per_turn = int(d.get("actions", 1))
	u.actions_left = u.actions_per_turn
	u.stagger_max = int(d.get("stagger_max", 0))
	return u
