class_name Tables
extends RefCounted
## Loads the JSON data tables under res://data/tables (the single source of tuning numbers).
## Tables are validated against JSON Schema by the Python balance tooling (`balance check`);
## here we only fail loudly if a file is missing or malformed.
##
## Overrides (parameter sweeps, A/B runs) come from command-line user args, without touching files:
##   --set=<table>:<dotted.key>=<json value>    e.g.  --set=units:heracles.str=16
## Overlays (level-editor variants) replace whole files:
##   --data-dir=<absolute dir>    a file <dir>/<table>.json wins over res://data/tables/<table>.json;
##                                battles that exist only in the overlay are listed too.

const ROOT := "res://data/tables/"

static var _cache := {}


static func get_table(name: String) -> Dictionary:
	if not _cache.has(name):
		var over := overlay_dir()
		var path := ROOT + name + ".json"
		if over != "" and FileAccess.file_exists(over.path_join(name + ".json")):
			path = over.path_join(name + ".json")
		var data := _load(path)
		for o in overrides():
			if o["table"] == name:
				_set_path(data, o["path"], o["value"], name)
		_cache[name] = data
	return _cache[name]


static func overlay_dir() -> String:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--data-dir="):
			return arg.trim_prefix("--data-dir=")
	return ""


## [{table, path: Array[String], value}] parsed from `--set=` user args.
static func overrides() -> Array:
	var out: Array = []
	for arg in OS.get_cmdline_user_args():
		if not arg.begins_with("--set="):
			continue
		var spec := arg.trim_prefix("--set=")
		var colon := spec.find(":")
		var eqi := spec.find("=")
		assert(colon > 0 and eqi > colon, "bad override %s (want table:key.path=value)" % arg)
		var raw := spec.substr(eqi + 1)
		var value = JSON.parse_string(raw)
		out.append({"table": spec.substr(0, colon), "path": spec.substr(colon + 1, eqi - colon - 1).split("."),
			"value": value if value != null else raw})
	return out


static func _set_path(data: Dictionary, path: PackedStringArray, value: Variant, table: String) -> void:
	var node: Dictionary = data
	for i in path.size() - 1:
		assert(node.has(path[i]) and node[path[i]] is Dictionary, "override path %s not found in %s" % [".".join(path), table])
		node = node[path[i]]
	assert(node.has(path[-1]), "override key %s not found in %s (overrides may only change existing values)" % [".".join(path), table])
	node[path[-1]] = value


static func battle(id: String) -> Dictionary:
	return get_table("battles/" + id)


## Battle ids sorted by their "order" field.
static func battle_ids() -> Array[String]:
	var entries: Array = []
	var files := {}
	for f in DirAccess.get_files_at(ROOT + "battles"):
		files[f] = true
	if overlay_dir() != "" and DirAccess.dir_exists_absolute(overlay_dir().path_join("battles")):
		for f in DirAccess.get_files_at(overlay_dir().path_join("battles")):
			files[f] = true
	for f in files:
		if f.ends_with(".json"):
			var id: String = f.trim_suffix(".json")
			entries.append([int(battle(id).get("order", 0)), id])
	entries.sort()
	var ids: Array[String] = []
	for e in entries:
		ids.append(e[1])
	return ids


## Drops cached tables (tests and parameter sweeps that rewrite tables at runtime).
static func reload() -> void:
	_cache.clear()


static func _load(path: String) -> Dictionary:
	var text := FileAccess.get_file_as_string(path)
	assert(text != "", "missing data table %s" % path)
	var data = JSON.parse_string(text)
	assert(data is Dictionary, "data table %s is not a JSON object" % path)
	return data
