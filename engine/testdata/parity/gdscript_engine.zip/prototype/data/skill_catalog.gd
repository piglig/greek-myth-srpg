class_name SkillCatalog
extends RefCounted
## Skill definitions from data/tables/skills.json.
## Fields: name, mult, type ("physical" | "divine" | "true"), min_range, max_range,
## shape ("single" | "line"), ranged, knockback, cooldown, stagger_bonus,
## marked_flank_stagger, leap, leap_rise.

const TYPE_NAMES := {
	"physical": Defs.DamageType.PHYSICAL,
	"divine": Defs.DamageType.DIVINE,
	"true": Defs.DamageType.TRUE,
}
const INT_FIELDS := ["min_range", "max_range", "knockback", "cooldown", "stagger_bonus",
	"marked_flank_stagger", "leap", "leap_rise"]

static var _resolved := {}


static func has_skill(id: String) -> bool:
	return Tables.get_table("skills").has(id)


## The skill with `type` resolved to Defs.DamageType and integer fields as ints.
static func get_skill(id: String) -> Dictionary:
	if not _resolved.has(id):
		var raw: Dictionary = Tables.get_table("skills").get(id, {})
		assert(not raw.is_empty(), "unknown skill %s" % id)
		var sk := raw.duplicate(true)
		if raw.has("type"):  # area-control skills (roar) deal no damage and have no type
			sk["type"] = TYPE_NAMES[raw["type"]]
		for f in ["radius", "rounds"]:
			if sk.has(f):
				sk[f] = int(sk[f])
		for f in INT_FIELDS:
			if sk.has(f):
				sk[f] = int(sk[f])
		_resolved[id] = sk
	return _resolved[id]


static func reload() -> void:
	_resolved.clear()
