class_name Battles
extends RefCounted
## Battle setups from data/tables/battles/<id>.json.

const TEAMS := {"player": Defs.Team.PLAYER, "enemy": Defs.Team.ENEMY, "neutral": Defs.Team.NEUTRAL}
const FACINGS := {"N": Defs.NORTH, "E": Defs.EAST, "S": Defs.SOUTH, "W": Defs.WEST}


static func ids() -> Array[String]:
	return Tables.battle_ids()


static func title(id: String) -> String:
	return Tables.battle(id).get("title", id)


## `picks`: def_id -> skill-tree node ids. Defaults to the table's default picks.
static func build(id: String, picks: Dictionary = {}) -> BattleState:
	var b := Tables.battle(id)
	var s := BattleState.new(BattleGrid.from_rows(b["heights"], b.get("terrain", [])))
	for e in b["units"]:
		var pos := Vector2i(int(e["pos"][0]), int(e["pos"][1]))
		s.add_unit(UnitCatalog.make(e["def"], e["id"], TEAMS[e["team"]], pos, FACINGS[e.get("facing", "S")]))
	if b.has("cave"):
		var c: Dictionary = b["cave"]
		var cave := {"boss": c["boss"], "trigger_hp": int(c["trigger_hp"]), "emerge_actions": int(c.get("emerge_actions", 1)),
			"last": "", "entrances": {}, "boulders": {}}
		for e in c["entrances"]:
			cave["entrances"][e["id"]] = {"anchor": Vector2i(int(e["anchor"][0]), int(e["anchor"][1])), "sealed": false}
		for bo in c.get("boulders", []):
			cave["boulders"][bo["id"]] = {"pos": Vector2i(int(bo["pos"][0]), int(bo["pos"][1])), "seals": bo["seals"],
				"progress": 0, "placed": false}
		s.cave = cave
	var use := picks if not picks.is_empty() else SkillTree.default_picks()
	for u in s.living(Defs.Team.PLAYER):
		SkillTree.apply(u, use.get(u.def_id, []))
	return s
