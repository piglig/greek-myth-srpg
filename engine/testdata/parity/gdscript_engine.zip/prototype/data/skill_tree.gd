class_name SkillTree
extends RefCounted
## Skill-tree nodes chosen before battle, from data/tables/skill_tree.json (docs/08).
## The hero's 容器 branch is left out until relics exist (first relic drops in 1-5).


static func points() -> int:
	return int(Tables.get_table("skill_tree")["points"])


## def_id -> [{branch, nodes: [{id, name, cost, trait|skill, desc}]}]
static func trees() -> Dictionary:
	return Tables.get_table("skill_tree")["trees"]


static func default_picks() -> Dictionary:
	return Tables.get_table("skill_tree")["default_picks"]


static func node(def_id: String, node_id: String) -> Dictionary:
	for branch in trees().get(def_id, []):
		for n in branch["nodes"]:
			if n["id"] == node_id:
				return n
	return {}


static func cost(def_id: String, picks: Array) -> int:
	var total := 0
	for id in picks:
		total += int(node(def_id, id).get("cost", 0))
	return total


## "" if the picks fit the budget and every later node has the node before it.
static func validate(def_id: String, picks: Array) -> String:
	for id in picks:
		if node(def_id, id).is_empty():
			return "unknown node"
	if cost(def_id, picks) > points():
		return "over budget"
	for branch in trees().get(def_id, []):
		var nodes: Array = branch["nodes"]
		for i in range(1, nodes.size()):
			if picks.has(nodes[i]["id"]) and not picks.has(nodes[i - 1]["id"]):
				return "missing prerequisite"
	return ""


## Every valid pick list for a unit (used to enumerate builds in balance runs).
static func all_builds(def_id: String) -> Array:
	var ids: Array = []
	for branch in trees().get(def_id, []):
		for n in branch["nodes"]:
			ids.append(n["id"])
	var out: Array = []
	for mask in range(1 << ids.size()):
		var picks: Array = []
		for i in ids.size():
			if mask & (1 << i):
				picks.append(ids[i])
		if validate(def_id, picks) == "":
			out.append(picks)
	return out


static func apply(u: UnitState, picks: Array) -> void:
	for id in picks:
		var n := node(u.def_id, id)
		if n.has("trait"):
			u.traits[n["trait"]] = true
		if n.has("skill") and not u.skills.has(n["skill"]):
			u.skills.append(n["skill"])
